# NoticeCenter
消息中心，实现消息的互通

scp NoticeService-0.0.1-SNAPSHOT.jar root@120.25.79.100:/data/notice_center

java -jar NoticeService-0.0.1-SNAPSHOT.jar
