package com.im.server.mode;

/**
 * Created by majun on 16/1/21.
 */
public class DominatoryAssistant {

}
