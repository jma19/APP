package com.im.server.api;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by majun on 16/2/6.
 */
@RestController
@RequestMapping("/activity/service")
public class ActivityCenterService{



}
