package com.im.server.utils;

/**
 * Created by majun on 16/1/20.
 */
public class ParamerChecker {

    public static boolean isNull(Object obj) {
        return obj == null;
    }
}
