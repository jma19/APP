package com.im.server.common;

import java.util.InputMismatchException;

/**
 * Created by majun on 15/12/28.
 */
public interface Constants {

    interface ERROR_CODE {
        String SYSTEM_ERROR = "SYSTEM_ERROR";
        String MISS_PARAM = "MISS_PARAM_ERROR";
    }

    int DES_TEXT_LENGTH = 15;

    interface Status {
        String SUCCESS = "SUCCESS";

        String ERROR = "ERROR";
    }

    interface Type{
        Integer STUDENT = 1;
        Integer ASSISTANT = 2;
    }


}
