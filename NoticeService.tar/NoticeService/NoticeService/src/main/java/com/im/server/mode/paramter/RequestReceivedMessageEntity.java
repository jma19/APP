package com.im.server.mode.paramter;

/**
 * Created by majun on 16/1/5.
 */
public class RequestReceivedMessageEntity {

}
