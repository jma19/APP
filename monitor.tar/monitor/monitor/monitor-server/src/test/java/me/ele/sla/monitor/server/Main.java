package me.ele.sla.monitor.server;

import me.ele.pylon.spring.util.Bootstrap;

/**
 * Created by yaofeng on 1/12/16.
 */
public class Main {

    public static void main(String[] args) {
        Bootstrap.main(null);
    }

}
