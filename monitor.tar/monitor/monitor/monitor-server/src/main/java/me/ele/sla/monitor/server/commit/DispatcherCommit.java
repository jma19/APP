package me.ele.sla.monitor.server.commit;

import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.lpd.core.util.JsonUtils;
import me.ele.sla.common.rmq.BaseCommit;
import me.ele.sla.common.rmq.BasePusher;

import java.io.IOException;

import org.springframework.amqp.core.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;


/**
 * Created by yaofeng on 1/12/16.
 */
@Service
public class DispatcherCommit extends BasePusher {

    private static final Log logger = LogFactory.getLog(DispatcherCommit.class);
    
    @Autowired
    CreateOrderCommit createOrderCommit;
    @Autowired
    AssignCarrierCommit assignCarrierCommit;
    @Autowired
    AssignCourierCommit assignCourierCommit;
    @Autowired
    CourierDeliveringCommit courierDeliveringCommit;
    @Autowired
    DeliverySuccessCommit deliverySuccessCommit;

    @Override
    protected void dispatcher(Message message) {
    	
    	switch (message.getMessageProperties().getReceivedRoutingKey()) {
			case "order.dist": createOrderCommit.doCommit(message); break;
			case "order.carrier.assignment": assignCarrierCommit.doCommit(message); break;
			case "order.carrier.driver.assignment": assignCourierCommit.doCommit(message); break;
			case "order.carrier.delivering": courierDeliveringCommit.doCommit(message); break;
			case "order.carrier.delivery.successed": deliverySuccessCommit.doCommit(message); break;
		default:
			logger.warn("routing_key:["+message.getMessageProperties().getReceivedRoutingKey()+"]no service."); break;
		}
    	
    }

}
