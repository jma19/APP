package me.ele.sla.monitor.server.lib;

public class CarrierIdConstant {
	
	public static Integer ZHONGBAO = 6;
	public static Integer TUANDUI = 5;
	public static Integer JINGDONG = 3;
	public static Integer BOD = 7;
	public static Integer QUANCHENGSONG = 8;
	
}
