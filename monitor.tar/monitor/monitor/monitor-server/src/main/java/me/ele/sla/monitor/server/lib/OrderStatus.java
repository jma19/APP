package me.ele.sla.monitor.server.lib;

public class OrderStatus {

	public static Integer ORDER_CREATE_STATUS = 1;
	public static Integer ORDER_ASSIGN_CARRIER_STATUS = 2;
	public static Integer ORDER_ASSIGN_COURIER_STATUS = 3;
	public static Integer ORDER_DELIVERING_STATUS = 4;
	public static Integer ORDER_DELIVERY_SUCCESS_STATUS = 5;
	public static Integer ORDER_CARRIER_CANCEL_STATUS = 6;
	public static Integer ORDER_DELIVERY_FAILED_STATUS = 7;
	public static Integer ORDER_MERCHANT_CANCEL_STATUS = 8;
	public static Integer ORDER_DELIVERY_EXCEPTION_STATUS = 9;
	
}
