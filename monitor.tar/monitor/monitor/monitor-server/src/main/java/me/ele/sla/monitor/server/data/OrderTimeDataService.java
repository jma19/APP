package me.ele.sla.monitor.server.data;

import java.util.Date;

import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonFormat.Value;

import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.lpd.redis.client.RedisClient;

@Service
public class OrderTimeDataService {
	
	@Autowired
	private RedisClient redisClient;
	
	private final static Log logger = LogFactory.getLog(OrderTimeDataService.class);
	
	private final static String KEY_PREFIX_ORDER_TIME = "ORDER_TIME_";
	private final static String KEY_PREFIX_CARRIER_TIME = "ORDER_CARRIER_TIME_";
	private final static String KEY_PREFIX_COURIER_TIME = "ORDER_COURIER_TIME_";
	private final static String KEY_PREFIX_DELIVERING_TIME = "ORDER_DELIVERING_TIME_";
	private final static String KEY_PREFIX_DELIVERY_SUCC_TIME = "ORDER_DELIVERY_SUCC_TIME_";
	private final static String KEY_PREFIX_DELIVERY_ALL_TIME = "ORDER_DELIVERY_ALL_TIME_";
	private final static Integer EXPIRE_TIME = 3600*3;
	
	public Integer getOrderStatusTime(Long orderId, Integer status) {
		String key = KEY_PREFIX_ORDER_TIME+orderId.toString() + "_" + status.toString();
		String value = redisClient.get(key);
		logger.info("Redis Get Key: [" + key + "] value: ["+value+"]");
		if(value == null) {
			logger.info("Redis Get Key:[" + key + "] Faild.");
			return null;
		}
		Integer time = new Integer(value);
		return time;
	}
	
	public void setOrderStatusTime(Long orderId, Integer status, Integer time) {
		String key = KEY_PREFIX_ORDER_TIME + orderId.toString() + "_" + status.toString();
		String value = time.toString();
		logger.info("Redis Set Key: [" + key + "] Value: ["+ value +"]");
		redisClient.setex(key, EXPIRE_TIME, value);
	}
	
	public void incAssignCarrierTimeAmount(Integer carrierId, Integer useTime) {
		Integer timeType = useTime / 60;
		String date = DateFormatUtils.format(new Date(), "yyMMdd");
		String key = KEY_PREFIX_CARRIER_TIME + carrierId.toString() + "_" + date + "_" + timeType.toString();
		logger.info("Redis Incr Key: [" + key + "]");
		redisClient.incr(key);
	}
	
	public Integer getAssignCarrierTimeAmount(Integer carrierId, Integer useTime, String date) {
		Integer timeType = useTime / 60;
		String key = KEY_PREFIX_CARRIER_TIME + carrierId.toString() + "_" + date + "_" + timeType.toString();
		Integer Amount = Integer.getInteger(redisClient.get(key));
		return Amount;
	}
	
	public void incAssignCourierTimeAmount(Integer carrierId, Integer productId, Integer useTime) {
		Integer timeType = useTime / 60 / 5;
		String date = DateFormatUtils.format(new Date(), "yyMMdd");
		String key = KEY_PREFIX_COURIER_TIME + carrierId.toString() + "_" + productId.toString() + "_" + date + "_" + timeType.toString();
		logger.info("Redis Incr Key: [" + key + "]");
		redisClient.incr(key);
	}
	
	public void incDeliveringTimeAmount(Integer carrierId, Integer productId, Integer useTime) {
		Integer timeType = useTime / 60 / 5;
		String date = DateFormatUtils.format(new Date(), "yyMMdd");
		String key = KEY_PREFIX_DELIVERING_TIME + carrierId.toString() + "_" + productId.toString() + "_" + date + "_" + timeType.toString();
		logger.info("Redis Incr Key: [" + key + "]");
		redisClient.incr(key);
	}
	
	public void incDeliverySuccTimeAmount(Integer carrierId, Integer productId, Integer useTime) {
		Integer timeType = useTime / 60 / 5;
		String date = DateFormatUtils.format(new Date(), "yyMMdd");
		String key = KEY_PREFIX_DELIVERY_SUCC_TIME + carrierId.toString() + "_" + productId.toString() + "_" + date + "_" + timeType.toString();
		logger.info("Redis Incr Key: [" + key + "]");
		redisClient.incr(key);
	}
	
	public void incDeliveryAllTimeAmount(Integer carrierId, Integer productId, Integer useTime) {
		Integer timeType = useTime / 60 / 5;
		String date = DateFormatUtils.format(new Date(), "yyMMdd");
		String key = KEY_PREFIX_DELIVERY_ALL_TIME + carrierId.toString() + "_" + productId.toString() + "_" + date + "_" + timeType.toString();
		logger.info("Redis Incr Key: [" + key + "]");
		redisClient.incr(key);
	}
	
}
