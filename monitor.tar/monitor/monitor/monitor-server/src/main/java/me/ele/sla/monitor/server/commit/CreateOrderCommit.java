package me.ele.sla.monitor.server.commit;

import java.io.IOException;

import org.springframework.amqp.core.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.lpd.core.util.JsonUtils;
import me.ele.sla.common.rmq.BaseCommit;
import me.ele.sla.monitor.server.data.OrderTimeDataService;
import me.ele.sla.monitor.server.lib.OrderStatus;

@Service
public class CreateOrderCommit extends BaseCommit{

	private final static Log logger = LogFactory.getLog(CreateOrderCommit.class);
	
	@Autowired
	OrderTimeDataService orderTimeDataService;
	
	@Override
	protected void doCommit(Message message) {

		String msgJson = new String(message.getBody());
		Long trackingId = 0L;
		Integer time = 0;

		try {
			trackingId = JsonUtils.getJsonNode(msgJson).get("payload").get("message").get("tracking_id").asLong();
			time = (int) (JsonUtils.getJsonNode(msgJson).get("payload").get("utc").asLong() / 1000);
		} catch (IOException e) {
			logger.warn("Apollo Message Format Error!");
			return ;
		}
		
		orderTimeDataService.setOrderStatusTime(trackingId, OrderStatus.ORDER_CREATE_STATUS, time);
	}

}
