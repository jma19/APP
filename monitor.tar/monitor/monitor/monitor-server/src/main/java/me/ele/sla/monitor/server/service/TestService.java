package me.ele.sla.monitor.server.service;

import org.springframework.stereotype.Service;

import me.ele.sla.monitor.api.service.ITestService;

@Service
public class TestService implements ITestService {

	@Override
	public void test() {
		System.out.println("hello world!");
	}

}
