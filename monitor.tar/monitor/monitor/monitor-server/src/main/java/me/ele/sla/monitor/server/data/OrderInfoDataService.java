package me.ele.sla.monitor.server.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import ch.qos.logback.classic.Logger;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.lpd.core.util.JsonUtils;
import me.ele.lpd.redis.client.RedisClient;
import me.ele.sla.common.thrift.zhongbaoSos.ShippingOrderService;
import me.ele.sla.common.thrift.zhongbaoSos.ShippingOrderSystemException;
import me.ele.sla.common.thrift.zhongbaoSos.ShippingOrderUnknownException;
import me.ele.sla.common.thrift.zhongbaoSos.ShippingOrderUserException;
import me.ele.sla.common.thrift.zhongbaoSos.TProductPrice;
import me.ele.sla.common.thrift.zhongbaoSos.TShippingOrder;
import me.ele.sla.monitor.server.model.OrderInfo;

@Service
public class OrderInfoDataService {
	
	private static final Log logger = LogFactory.getLog(OrderInfoDataService.class);
	
	private static final String INFO_PREFIX = "ORDER_INFO_";
	private static final Integer EXPIRE_TIME = 3600*4;
	
	@Autowired
	RedisClient redisClient;
	@Autowired
	ShippingOrderService shippingOrderService;
	
	protected String getKey(Long orderId) {
		String key = orderId.toString();
		return key;
	}
	
	protected OrderInfo getFromRedis(Long orderId) {
		String key = this.getKey(orderId);
		OrderInfo orderInfo = JsonUtils.fromJson(redisClient.get(key), OrderInfo.class);
		return orderInfo;
	}
	
	protected void setRedis(OrderInfo orderInfo) {
		String key = this.getKey(orderInfo.getOrderId());
		redisClient.setex(key, EXPIRE_TIME, JsonUtils.toJson(orderInfo));
	}
	
	protected OrderInfo getFromRpc(Long orderId) {
		OrderInfo orderInfo = new OrderInfo();
		
		List<Long> orderIds = new ArrayList<Long>();
		orderIds.add(orderId);
		
		TShippingOrder shippingOrder;
		TProductPrice productPrice;
		
		try {
			shippingOrder = shippingOrderService.mget_orders_by_tracking_ids(orderIds).get(0);
			orderInfo.setOrderId(orderId);
			orderInfo.setType(shippingOrder.getShipping_state());
			Long productId = Long.getLong(shippingOrder.getProduct_id().toString());
			productPrice = shippingOrderService.query_product_by_id(productId);
			orderInfo.setProductId(productPrice.getMerchant_type());
		} catch (ShippingOrderUnknownException e) {
			logger.warn("Get Zhongbao OrderInfo Error, OrderId["+orderId.toString()+"]");
			return null;
		} catch (ShippingOrderUserException e) {
			logger.warn("Get Zhongbao OrderInfo Error, OrderId["+orderId.toString()+"]");
			return null;
		} catch (ShippingOrderSystemException e) {
			logger.warn("Get Zhongbao OrderInfo Error, OrderId["+orderId.toString()+"]");
			return null;
		}
		
		this.setRedis(orderInfo);
		
		return orderInfo;
	}
	
	public OrderInfo getOrderInfo(Long orderId) {
		OrderInfo orderInfo = this.getFromRedis(orderId);
		if (null == orderInfo) {
			orderInfo = this.getFromRpc(orderId);
		}
		return orderInfo;
	}

}
