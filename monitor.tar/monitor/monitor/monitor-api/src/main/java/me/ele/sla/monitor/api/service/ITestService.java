package me.ele.sla.monitor.api.service;

public interface ITestService {

	public void test();
}
