package me.ele.sla.monitor.ui;

import me.ele.pylon.spring.util.Bootstrap;

public class Main {

	public static void main(String[] args) {
		Bootstrap.main(null);
	}
	
}
