#!/bin/sh
mkdir outfile
cp deploy/award_tk/appspec.yml outfile/
cp deploy/award_tk/start.sh.etpl outfile/
#cp deplpy/award_tk/validate.sh outfile/
unzip -d outfile/ award/award-dist-tk/target/lpd.quality.award_tk.zip 
