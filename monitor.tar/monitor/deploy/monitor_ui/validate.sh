#!/usr/bin/env bash
URL="http://127.0.0.1:`expr {{_ .APP_PORT}} + 1`/heartbeat";
echo $URL
while [ true ]
do
sleep 1
HTTP_CODE=`curl -G -m 10 -o /dev/null -s -w %{http_code} $URL`
echo "http code: ${HTTP_CODE}"
if [ ${HTTP_CODE} -eq 200 ]
then
exit 0
fi
done
