#!/bin/sh
mkdir outfile
cp deploy/monitor_ui/appspec.yml outfile/
cp deploy/monitor_ui/start.sh.etpl outfile/
#cp deplpy/award_tk/validate.sh outfile/
unzip -d outfile/ monitor/monitor-dist-ui/target/lpd.quality.monitor_ui.zip 
