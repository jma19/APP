package me.ele.feedback.api.bean;

/**
 * Created by majun on 16/1/25.
 */
public class ComplainObject {
    private Long id;
    private String phone;
    private String name;

    public Long getId() {
        return id;
    }

    public ComplainObject setId(Long id) {
        this.id = id;
        return this;
    }

    public String getPhone() {
        return phone;
    }

    public ComplainObject setPhone(String phone) {
        this.phone = phone;
        return this;
    }

    public String getName() {
        return name;
    }

    public ComplainObject setName(String name) {
        this.name = name;
        return this;
    }

    @Override
    public String toString() {
        return "ComplainObject{" +
                "id=" + id +
                ", phone='" + phone + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
