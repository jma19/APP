package me.ele.feedback.api.dto;

public class UpdateFeedbackDto {
	private int id;
	private int status;

	public int getId() {
		return id;
	}

	public UpdateFeedbackDto setId(int id) {
		this.id = id;
		return this;
	}

	public int getStatus() {
		return status;
	}

	public UpdateFeedbackDto setStatus(int status) {
		this.status = status;
		return this;
	}

	public UpdateFeedbackDto() {
		super();
	}

	@Override
	public String toString() {
		return "UpdateFeedbackDto:[id: " + id + " , status: " + status + " ]";
	}
}
