package me.ele.feedback.api.dto;

import me.ele.feedback.api.bean.ComplainObject;

import java.util.List;

/**
 * Created by majun on 16/1/25.
 */
public class FeedbackTicketDto {

    private Integer sourceId;
    private Integer productId;
    private Integer complainType;
    private List<Integer> complainReasonIds;
    private Long trackingId;
    private String orderId;
    private Long complainAt;
    private Long solvedAt;
    private ComplainObject complainSource;
    private ComplainObject complainTarget;
    private String remark;

    public Long getComplainAt() {
        return complainAt;
    }

    public FeedbackTicketDto setComplainAt(Long complainAt) {
        this.complainAt = complainAt;
        return this;
    }

    public Long getSolvedAt() {
        return solvedAt;
    }

    public FeedbackTicketDto setSolvedAt(Long solvedAt) {
        this.solvedAt = solvedAt;
        return this;
    }

    public Integer getSourceId() {
        return sourceId;
    }

    public FeedbackTicketDto setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
        return this;
    }

    public Integer getProductId() {
        return productId;
    }

    public FeedbackTicketDto setProductId(Integer productId) {
        this.productId = productId;
        return this;
    }

    public Integer getComplainType() {
        return complainType;
    }

    public FeedbackTicketDto setComplainType(Integer complainType) {
        this.complainType = complainType;
        return this;
    }

    public List<Integer> getComplainReasonIds() {
        return complainReasonIds;
    }

    public FeedbackTicketDto setComplainReasonIds(List<Integer> complainReasonIds) {
        this.complainReasonIds = complainReasonIds;
        return this;
    }

    public Long getTrackingId() {
        return trackingId;
    }

    public FeedbackTicketDto setTrackingId(Long trackingId) {
        this.trackingId = trackingId;
        return this;
    }

    public String getOrderId() {
        return orderId;
    }

    public FeedbackTicketDto setOrderId(String orderId) {
        this.orderId = orderId;
        return this;
    }

    public ComplainObject getComplainSource() {
        return complainSource;
    }

    public FeedbackTicketDto setComplainSource(ComplainObject complainSource) {
        this.complainSource = complainSource;
        return this;
    }

    public ComplainObject getComplainTarget() {
        return complainTarget;
    }

    public FeedbackTicketDto setComplainTarget(ComplainObject complainTarget) {
        this.complainTarget = complainTarget;
        return this;
    }

    public String getRemark() {
        return remark;
    }

    public FeedbackTicketDto setRemark(String remark) {
        this.remark = remark;
        return this;
    }

    @Override
    public String toString() {
        return "FeedbackTicketDto{" +
                "sourceId=" + sourceId +
                ", productId=" + productId +
                ", complainType=" + complainType +
                ", complainReasonIds=" + complainReasonIds +
                ", trackingId=" + trackingId +
                ", orderId='" + orderId + '\'' +
                ", complainSource=" + complainSource +
                ", complainTarget=" + complainTarget +
                ", remark='" + remark + '\'' +
                '}';
    }
}
