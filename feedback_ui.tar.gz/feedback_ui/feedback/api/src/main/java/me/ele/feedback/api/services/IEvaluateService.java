package me.ele.feedback.api.services;

import me.ele.contract.exception.ServiceException;
import me.ele.feedback.api.dto.EvaluateTicketDto;
import me.ele.feedback.api.bean.TagEntity;

import java.util.List;

/**
 * Created by majun on 16/2/23.
 */
public interface IEvaluateService {

    List<TagEntity> getCustomerEvaDriverTags(Integer star, String orderId) throws ServiceException;

    void createEvaTicket(EvaluateTicketDto evaluateTicketDto) throws ServiceException;
}
