package me.ele.feedback.api.bean;

import java.sql.Timestamp;

public class FeedbackEntity {
	private int id;
	private long waybill_num;
	private int product_id;
	private String complaint_phone;
	private String knight_name;
	private String knight_phone;
	private int type;
	private String content;
	private Timestamp created_at;
	private Timestamp updated_at;
	private Timestamp finished_at;
	private int channel;
	private int role;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getWaybill_num() {
		return waybill_num;
	}

	public void setWaybill_num(long waybill_num) {
		this.waybill_num = waybill_num;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getComplaint_phone() {
		return complaint_phone;
	}

	public void setComplaint_phone(String complaint_phone) {
		this.complaint_phone = complaint_phone;
	}

	public String getKnight_name() {
		return knight_name;
	}

	public void setKnight_name(String knight_name) {
		this.knight_name = knight_name;
	}

	public String getKnight_phone() {
		return knight_phone;
	}

	public void setKnight_phone(String knight_phone) {
		this.knight_phone = knight_phone;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Timestamp getCreated_at() {
		return created_at;
	}

	public void setCreated_at(Timestamp created_at) {
		this.created_at = created_at;
	}

	public Timestamp getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(Timestamp updated_at) {
		this.updated_at = updated_at;
	}

	public Timestamp getFinished_at() {
		return finished_at;
	}

	public void setFinished_at(Timestamp finished_at) {
		this.finished_at = finished_at;
	}

	public int getChannel() {
		return channel;
	}

	public void setChannel(int channel) {
		this.channel = channel;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public FeedbackEntity() {
		super();
	}

	@Override
	public String toString() {
		return "FeedbackDto: [id: " + id + ", waybill_num: " + waybill_num + ", product_id: " + product_id
				+ ", complaint_phone: " + complaint_phone + ", knight_name: " + knight_name + ", knight_phone: "
				+ knight_phone + ", type: " + type + ", content: " + content + ", created_at: " + created_at
				+ ", updated_at: " + updated_at + ", finished_at: " + finished_at + ", channel: " + channel + ", role: "
				+ role + "]";
	}
}
