package me.ele.feedback.api.dto;

import java.util.List;
/**
 * Created by majun on 16/2/23.
 */
public class EvaluateTicketDto {

    private Integer star;
    private List<Integer> tagIds;
    private String orderId;
    private Long trackingId;
    private String sourceName;
    private String sourcePhone;
    private String targetName;
    private String targetPhone;
    private String remark;

    public String getOrderId() {
        return orderId;
    }

    public EvaluateTicketDto setOrderId(String orderId) {
        this.orderId = orderId;
        return this;
    }

    public String getRemark() {
        return remark;
    }

    public EvaluateTicketDto setRemark(String remark) {
        this.remark = remark;
        return this;
    }

    public String getSourceName() {
        return sourceName;
    }

    public EvaluateTicketDto setSourceName(String sourceName) {
        this.sourceName = sourceName;
        return this;
    }

    public String getSourcePhone() {
        return sourcePhone;
    }

    public EvaluateTicketDto setSourcePhone(String sourcePhone) {
        this.sourcePhone = sourcePhone;
        return this;
    }

    public Integer getStar() {
        return star;
    }

    public EvaluateTicketDto setStar(Integer star) {
        this.star = star;
        return this;
    }

    public List<Integer> getTagIds() {
        return tagIds;
    }

    public EvaluateTicketDto setTagIds(List<Integer> tagIds) {
        this.tagIds = tagIds;
        return this;
    }

    public String getTargetName() {
        return targetName;
    }

    public EvaluateTicketDto setTargetName(String targetName) {
        this.targetName = targetName;
        return this;
    }

    public String getTargetPhone() {
        return targetPhone;
    }

    public EvaluateTicketDto setTargetPhone(String targetPhone) {
        this.targetPhone = targetPhone;
        return this;
    }

    public Long getTrackingId() {
        return trackingId;
    }

    public EvaluateTicketDto setTrackingId(Long trackingId) {
        this.trackingId = trackingId;
        return this;
    }

    @Override
    public String toString() {
        return "EvaluateTicketDto{" +
                "orderId='" + orderId + '\'' +
                ", star=" + star +
                ", tagIds=" + tagIds +
                ", trackingId=" + trackingId +
                ", sourceName='" + sourceName + '\'' +
                ", sourcePhone='" + sourcePhone + '\'' +
                ", targetName='" + targetName + '\'' +
                ", targetPhone='" + targetPhone + '\'' +
                ", remark='" + remark + '\'' +
                '}';
    }
}
