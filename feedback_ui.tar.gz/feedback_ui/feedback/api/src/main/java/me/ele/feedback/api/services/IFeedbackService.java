package me.ele.feedback.api.services;

import java.util.List;

import me.ele.contract.exception.ServerException;
import me.ele.contract.exception.ServiceException;
import me.ele.feedback.api.dto.FeedbackTicketDto;
import me.ele.feedback.api.dto.FeedbackDto;
import me.ele.feedback.api.dto.UpdateFeedbackDto;

public interface IFeedbackService {

	void updateFeedback(UpdateFeedbackDto updateFeedbackDto) throws ServiceException, ServerException;

	void addFeedback(FeedbackDto feedbackDto) throws ServiceException, ServerException;

	List<Long> getWaybillNumByDateProduct(String date, Integer productId, Integer page, String sign) throws ServiceException, ServerException;

	List<Long> getWaybillNumByDateTypeProduct(String date, Integer productId, String types, Integer page, String sign) throws ServiceException, ServerException;

	int getCountByDateProduct(String date, int productId, String sign) throws ServiceException, ServerException;
	
	int getCountByDateTypeProduct(String date, int productId, String types, String sign) throws ServiceException, ServerException;

	void createFeedbackTicket(FeedbackTicketDto feedbackTicket) throws ServiceException;
}
