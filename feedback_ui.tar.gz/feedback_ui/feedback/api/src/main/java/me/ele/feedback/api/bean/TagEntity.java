package me.ele.feedback.api.bean;

/**
 * Created by majun on 16/2/23.
 */
public class TagEntity {
    private Integer id;
    private Integer star;
    private String content;

    public TagEntity(Integer id, Integer star, String content) {
        this.star = star;
        this.content = content;
        this.id = id;
    }

    public Integer getStar() {
        return star;
    }

    public TagEntity setStar(Integer star) {
        this.star = star;
        return this;
    }

    public TagEntity() {
        super();
    }

    public String getContent() {
        return content;
    }

    public TagEntity setContent(String content) {
        this.content = content;
        return this;
    }

    public Integer getId() {
        return id;
    }

    public TagEntity setId(Integer id) {
        this.id = id;
        return this;
    }

    @Override
    public String toString() {
        return "TagEntity{" +
                "content='" + content + '\'' +
                ", id=" + id +
                '}';
    }
}
