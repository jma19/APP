package me.ele.feedback.api.dto;

import java.util.ArrayList;
import java.util.List;

public class FeedbackDto {
	private int id;
	private long waybill_num;
	private int product_id;
	private String complaint_phone;
	private String knight_name;
	private String knight_phone;
	private List<Integer> types = new ArrayList<>();
	private String content;

	public List<Integer> getTypes() {
		return types;
	}

	public FeedbackDto setTypes(List<Integer> types) {
		this.types = types;
		return this;
	}


	public int getId() {
		return id;
	}

	public FeedbackDto setId(int id) {
		this.id = id;
		return this;
	}

	public long getWaybill_num() {
		return waybill_num;
	}

	public FeedbackDto setWaybill_num(long waybill_num) {
		this.waybill_num = waybill_num;
		return this;
	}

	public int getProduct_id() {
		return product_id;
	}

	public FeedbackDto setProduct_id(int product_id) {
		this.product_id = product_id;
		return this;
	}

	public String getComplaint_phone() {
		return complaint_phone;
	}

	public FeedbackDto setComplaint_phone(String complaint_phone) {
		this.complaint_phone = complaint_phone;
		return this;
	}

	public String getKnight_name() {
		return knight_name;
	}

	public FeedbackDto setKnight_name(String knight_name) {
		this.knight_name = knight_name;
		return this;
	}

	public String getKnight_phone() {
		return knight_phone;
	}

	public FeedbackDto setKnight_phone(String knight_phone) {
		this.knight_phone = knight_phone;
		return this;
	}

	public String getContent() {
		return content;
	}

	public FeedbackDto setContent(String content) {
		this.content = content;
		return this;
	}

	@Override
	public String toString() {
		return "FeedbackDto: [id: " + id + ", waybill_num: " + waybill_num + ", product_id: " + product_id
				+ ", complaint_phone: " + complaint_phone + ", knight_name: " + knight_name + ", knight_phone: "
				+ knight_phone + ", types: " + types + ", content: " + content + "]";
	}

	public FeedbackDto() {
		super();
	}

}
