struct EvaluateTicketDto {
    1: i32 star,  // 星级
    2: list<i32> tagIds,  // 选择的tagIds
    3: string orderId,    // 订单id
    4: i64 trackingId,     //运单id
    5: string sourceName,  //评价人姓名
    6: string sourcePhone, // 评价人手机号
    7: string targetName, // 被评价人姓名
    8: string targetPhone, // 被评价人手机号
    9: string remark, // 备注
}

struct TagEntity {
    1: i32 id,     // ]标签 id
    2: i32 star, //星级
    3: string content,    //标签内容
}

exception SystemException {
    1: string cl,
    2: string msg,
    3: map<string, string> fields
}
exception ServiceException {
    1: string cl,
    2: string msg,
    3: map<string, string> fields
}
exception RpcException {
    1: string cl,
    2: string msg,
    3: map<string, string> fields
}

service IEvaluateService {

    /**
	 * 根据star和orderId返回指定的tags
	 */
    list<TagEntity> getCustomerEvaDriverTags(1: i32 star, 2: string orderId) throws (
        1: SystemException system_exception,
        2: ServiceException service_exception,
        3: RpcException rpc_exception
    )

    /**
	 * 评价接口
	 */
	void createEvaTicket(1:  EvaluateTicketDto evaluateTicketDto) throws (
	    1: SystemException system_exception,
        2: ServiceException service_exception,
        3: RpcException rpc_exception
	)

}
