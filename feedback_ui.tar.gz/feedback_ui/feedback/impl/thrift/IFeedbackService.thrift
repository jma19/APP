struct ComplainObject {
    1: i64 id,  // 投诉人或被投诉人id
    2: string phone, //投诉人手机号
    3: string name, // 投诉人姓名
}

struct FeedbackTicketDto {
    1: i32 sourceId,  // 渠道id
    2: i32 productId, //
    3: i32 complainType,
    4: list<i32> complainReasonIds,  // 选择的tagIds
    5: i64 trackingId,     //运单id
    6: string orderId,    // 订单id
    7: i64 complainAt, // 投诉时间
    8: i64 solvedAt, // 解决时间
    9: ComplainObject complainSource,  //投诉人
    10: ComplainObject complainTarget, //被投诉人
    11: string remark, // 备注
}


exception SystemException {
    1: string cl,
    2: string msg,
    3: map<string, string> fields
}
exception ServiceException {
    1: string cl,
    2: string msg,
    3: map<string, string> fields
}
exception RpcException {
    1: string cl,
    2: string msg,
    3: map<string, string> fields
}

service IFeedbackService {

    /**
	 * 评价接口
	 */
	void createFeedbackTicket(1:  FeedbackTicketDto feedbackTicket) throws (
	    1: SystemException system_exception,
        2: ServiceException service_exception,
        3: RpcException rpc_exception
	)

}
