package me.ele.feedback.lib.sos;
import me.ele.contract.exception.thrift.TUserException;

@SuppressWarnings("serial")
public class AuroraUserException extends TUserException {
    public AuroraUserException(String code, String message) {
        super(code, message);
    }
}
