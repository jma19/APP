package me.ele.feedback.utils;

import com.google.common.base.Strings;

/**
 * Created by majun on 16/1/25.
 */
public class ParameterChecker {

    public static boolean isNull(Object object) {
        return object == null;
    }

    public static boolean isNull(String str) {
        return Strings.isNullOrEmpty(str);
    }
}
