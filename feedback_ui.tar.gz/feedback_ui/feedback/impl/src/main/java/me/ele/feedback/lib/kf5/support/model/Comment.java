package me.ele.feedback.lib.kf5.support.model;

import java.util.ArrayList;
import java.util.List;

public class Comment {

	private int id;
	
	private String  content;
	
	private String html_content;
	
	private boolean isPublic;
	
	private String created_at;
	
	private int author_id;
	
	private String author_name;
	
	private List<Attachment> listAttachments = new ArrayList<>();

	public int getId() {
		return id;
	}

	public Comment setId(int id) {
		this.id = id;
		return this;
	}

	public String getContent() {
		return content;
	}

	public Comment setContent(String content) {
		this.content = content;
		return this;
	}

	public String getHtml_content() {
		return html_content;
	}

	public Comment setHtml_content(String html_content) {
		this.html_content = html_content;
		return this;
	}

	public boolean isPublic() {
		return isPublic;
	}

	public Comment setPublic(boolean isPublic) {
		this.isPublic = isPublic;
		return this;
	}

	public String getCreated_at() {
		return created_at;
	}

	public Comment setCreated_at(String created_at) {
		this.created_at = created_at;
		return this;
	}

	public int getAuthor_id() {
		return author_id;
	}

	public Comment setAuthor_id(int author_id) {
		this.author_id = author_id;
		return this;
	}

	public String getAuthor_name() {
		return author_name;
	}

	public Comment setAuthor_name(String author_name) {
		this.author_name = author_name;
		return this;
	}

	public List<Attachment> getListAttachments() {
		return listAttachments;
	}

	public Comment setListAttachments(List<Attachment> listAttachments) {
		this.listAttachments = listAttachments;
		return this;
	}

	@Override
	public String toString() {
		return "Comment{" +
				"author_id=" + author_id +
				", id=" + id +
				", content='" + content + '\'' +
				", html_content='" + html_content + '\'' +
				", isPublic=" + isPublic +
				", created_at='" + created_at + '\'' +
				", author_name='" + author_name + '\'' +
				", listAttachments=" + listAttachments +
				'}';
	}
}
