package me.ele.feedback.lib.kf5.support.model.request;

/**
 * Created by majun on 16/1/19.
 */
public class Requester {
    private String email;
    private String name;

    public String getEmail() {
        return email;
    }

    public Requester setEmail(String email) {
        this.email = email;
        return this;
    }

    public String getName() {
        return name;
    }

    public Requester setName(String name) {
        this.name = name;
        return this;
    }

    @Override
    public String toString() {
        return "Requester{" +
                "email='" + email + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
