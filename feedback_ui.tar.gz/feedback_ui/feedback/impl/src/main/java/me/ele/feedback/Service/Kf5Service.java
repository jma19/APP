package me.ele.feedback.Service;

import com.google.common.collect.Lists;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.feedback.api.dto.FeedbackTicketDto;
import me.ele.feedback.bean.Reason;
import me.ele.feedback.lib.kf5.support.controller.KF5Support;
import me.ele.feedback.lib.kf5.support.model.Comment;
import me.ele.feedback.lib.kf5.support.model.Ticket;
import me.ele.feedback.lib.kf5.support.model.request.CreateTicketBody;
import me.ele.feedback.lib.kf5.support.model.request.CreateTicketEntity;
import me.ele.feedback.utils.JsonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.stream.Collectors;

import static me.ele.feedback.constant.PublicConstants.*;

/**
 * Created by majun on 16/1/26.
 */
@Service
public class Kf5Service {

    private final static Log logger = LogFactory.getLog(Kf5Service.class);

    private KF5Support kf5Support;

    @Autowired
    private UserFiledFillOutService userFiledFillOutService;

    @PostConstruct
    public void initService() {
        kf5Support = new KF5Support();
        kf5Support.initWithApiToken("fengniao.kf5.com", "feng.yaosh@ele.me", "b080df1862d94eea87f7039398ad6c");
    }


    public Ticket createTicket(FeedbackTicketDto feedbackInsertDto) {

        Comment comment = new Comment()
                .setContent(getContent(feedbackInsertDto)).setPublic(true);

        CreateTicketBody ticketRequestBody = new CreateTicketBody()
                .setTitle(getTitle(feedbackInsertDto.getProductId(), feedbackInsertDto.getComplainType()))
                .setComment(comment)
                .setCustom_fields(userFiledFillOutService.createCustomFilelds(feedbackInsertDto));

        String jsonString = JsonUtils.toJson(new CreateTicketEntity().setTicket(ticketRequestBody));
        logger.info("创建工单, 输入参数 jsonStr={}", jsonString);
        return kf5Support.createAgentOrder(jsonString);

    }

    private String getContent(FeedbackTicketDto feedbackInsertDto) {

        return new StringBuilder()
                .append("1. 渠道: " + sourceMap.get(feedbackInsertDto.getSourceId()) + " ")
                .append("2. 产品线: " + productTypesMap.get(feedbackInsertDto.getProductId()) + " ")
                .append("3. 运单号: " + feedbackInsertDto.getTrackingId() + " ")
                .append("4. 订单号: " + feedbackInsertDto.getOrderId() + " ")
                .append("5. 投诉人: " + feedbackInsertDto.getComplainSource() + " ")
                .append("6. 被投诉人: " + feedbackInsertDto.getComplainTarget() + " ")
                .append("7. 投诉Reason: " + getReasons(feedbackInsertDto.getComplainReasonIds()) + " ")
                .append("8. 备注: " + feedbackInsertDto.getRemark()).toString();
    }

    private List<Reason> getReasons(List<Integer> complianReasonIds) {
        if (complianReasonIds == null || complianReasonIds.isEmpty()) {
            return Lists.newArrayList();
        }
        return complianReasonIds.stream()
                .map(value -> new Reason().setReasonId(value).setReasonName(feedbackReasonsMap.get(value)))
                .collect(Collectors.toList());
    }

    private String getTitle(Integer productId, Integer complainType) {
        return new StringBuilder().append(productTypesMap.get(productId))
                .append("--").append(complainTypesMap.get(complainType)).toString();
    }
}
