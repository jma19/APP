package me.ele.feedback.bean;

import java.sql.Timestamp;

/**
 * Created by majun on 16/3/3.
 */
public class SuggestionTicket {
    private Integer sourceId;
    private Integer productId;
    private Long sugSourceId;
    private String sugSourceName;
    private String sugSourcePhone;
    private Long sugTargetId;
    private String sugTargetName;
    private String sugTargetPhone;
    private Timestamp sugAt;
    private String remark;


    public String getSugSourcePhone() {
        return sugSourcePhone;
    }

    public SuggestionTicket setSugSourcePhone(String sugSourcePhone) {
        this.sugSourcePhone = sugSourcePhone;
        return this;
    }

    public String getSugTargetPhone() {
        return sugTargetPhone;
    }

    public SuggestionTicket setSugTargetPhone(String sugTargetPhone) {
        this.sugTargetPhone = sugTargetPhone;
        return this;

    }


    public Integer getProductId() {
        return productId;
    }

    public SuggestionTicket setProductId(Integer productId) {
        this.productId = productId;
        return this;
    }

    public String getRemark() {
        return remark;
    }

    public SuggestionTicket setRemark(String remark) {
        this.remark = remark;
        return this;
    }

    public Integer getSourceId() {
        return sourceId;
    }

    public SuggestionTicket setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
        return this;
    }

    public Timestamp getSugAt() {
        return sugAt;
    }

    public SuggestionTicket setSugAt(Timestamp sugAt) {
        this.sugAt = sugAt;
        return this;
    }

    public Long getSugSourceId() {
        return sugSourceId;
    }

    public SuggestionTicket setSugSourceId(Long sugSourceId) {
        this.sugSourceId = sugSourceId;
        return this;
    }

    public String getSugSourceName() {
        return sugSourceName;
    }

    public SuggestionTicket setSugSourceName(String sugSourceName) {
        this.sugSourceName = sugSourceName;
        return this;
    }

    public Long getSugTargetId() {
        return sugTargetId;
    }

    public SuggestionTicket setSugTargetId(Long sugTargetId) {
        this.sugTargetId = sugTargetId;
        return this;
    }

    public String getSugTargetName() {
        return sugTargetName;
    }

    public SuggestionTicket setSugTargetName(String sugTargetName) {
        this.sugTargetName = sugTargetName;
        return this;
    }

    @Override
    public String toString() {
        return "SuggestionTicket{" +
                "productId=" + productId +
                ", sourceId=" + sourceId +
                ", sugSourceId=" + sugSourceId +
                ", sugSourceName='" + sugSourceName + '\'' +
                ", sugSourcePhone='" + sugSourcePhone + '\'' +
                ", sugTargetId=" + sugTargetId +
                ", sugTargetName='" + sugTargetName + '\'' +
                ", sugTargetPhone='" + sugTargetPhone + '\'' +
                ", sugAt=" + sugAt +
                ", remark='" + remark + '\'' +
                '}';
    }
}
