package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TBill {

	private @Index(1) double receivables;
	
	private @Index(2) double payables;
	
	private @Index(3) double merchant_fee;
	
	private @Index(4) double food_amount;

	private @Index(5) double merchant_base_fee;

	private @Index(6) double merchant_extra_fee;

	private @Index(7) double merchant_cancel_fee;

	private @Index(8) String merchant_extra_fee_detail;

	private @Index(9) short merchant_fee_cal_flag;

	private @Index(10) short merchant_cancel_fee_cal_flag;

	public double getReceivables() {
		return receivables;
	}

	public void setReceivables(double receivables) {
		this.receivables = receivables;
	}

	public double getPayables() {
		return payables;
	}

	public void setPayables(double payables) {
		this.payables = payables;
	}

	public double getMerchant_fee() {
		return merchant_fee;
	}

	public void setMerchant_fee(double merchant_fee) {
		this.merchant_fee = merchant_fee;
	}

	public double getFood_amount() {
		return food_amount;
	}

	public void setFood_amount(double food_amount) {
		this.food_amount = food_amount;
	}

	public double getMerchant_base_fee() {
		return merchant_base_fee;
	}

	public void setMerchant_base_fee(double merchant_base_fee) {
		this.merchant_base_fee = merchant_base_fee;
	}

	public double getMerchant_extra_fee() {
		return merchant_extra_fee;
	}

	public void setMerchant_extra_fee(double merchant_extra_fee) {
		this.merchant_extra_fee = merchant_extra_fee;
	}

	public double getMerchant_cancel_fee() {
		return merchant_cancel_fee;
	}

	public void setMerchant_cancel_fee(double merchant_cancel_fee) {
		this.merchant_cancel_fee = merchant_cancel_fee;
	}

	public String getMerchant_extra_fee_detail() {
		return merchant_extra_fee_detail;
	}

	public void setMerchant_extra_fee_detail(String merchant_extra_fee_detail) {
		this.merchant_extra_fee_detail = merchant_extra_fee_detail;
	}

	public short getMerchant_fee_cal_flag() {
		return merchant_fee_cal_flag;
	}

	public void setMerchant_fee_cal_flag(short merchant_fee_cal_flag) {
		this.merchant_fee_cal_flag = merchant_fee_cal_flag;
	}

	public short getMerchant_cancel_fee_cal_flag() {
		return merchant_cancel_fee_cal_flag;
	}

	public void setMerchant_cancel_fee_cal_flag(short merchant_cancel_fee_cal_flag) {
		this.merchant_cancel_fee_cal_flag = merchant_cancel_fee_cal_flag;
	}

	@Override
	public String toString() {
		return "TBill [receivables=" + receivables + ", payables=" + payables + ", merchant_fee=" + merchant_fee
				+ ", food_amount=" + food_amount + ", merchant_base_fee=" + merchant_base_fee + ", merchant_extra_fee="
				+ merchant_extra_fee + ", merchant_cancel_fee=" + merchant_cancel_fee + ", merchant_extra_fee_detail="
				+ merchant_extra_fee_detail + ", merchant_fee_cal_flag=" + merchant_fee_cal_flag
				+ ", merchant_cancel_fee_cal_flag=" + merchant_cancel_fee_cal_flag + "]";
	}

}
