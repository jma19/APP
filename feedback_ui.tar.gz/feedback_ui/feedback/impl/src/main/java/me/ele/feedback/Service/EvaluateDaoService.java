package me.ele.feedback.Service;

import me.ele.contract.exception.ServiceException;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.feedback.api.dto.EvaluateTicketDto;
import me.ele.feedback.bean.EvaluationTicket;
import me.ele.feedback.constant.PublicConstants;
import me.ele.feedback.dao.EvaluationServiceDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

import static me.ele.feedback.constant.ExceptionConstants.ACCEESS_DB_EXCEPTION;

/**
 * Created by majun on 16/2/25.
 */
@Service
public class EvaluateDaoService {

    private final static Log logger = LogFactory.getLog(EvaluateDaoService.class);

    @Autowired
    private EvaluationServiceDao evaluationServiceDao;


    public void createEvaluateTickets(EvaluateTicketDto evaluateTicketDto) throws ServiceException {
        try {
            evaluationServiceDao.createEvaluationTickets(getEvaluationTickets(evaluateTicketDto));
            logger.info("插入评价信息成功!!!");
        } catch (Exception exp) {
            logger.error("操作数据库异常, 创建评价tickets失败", exp);
            throw ACCEESS_DB_EXCEPTION;
        }
    }

    private List<EvaluationTicket> getEvaluationTickets(EvaluateTicketDto evaluateTicketDto) {
        return evaluateTicketDto.getTagIds().stream()
                .map(tagId -> getEvaluateTicket(evaluateTicketDto, tagId)).collect(Collectors.toList());
    }

    private EvaluationTicket getEvaluateTicket(EvaluateTicketDto evaluateTicketDto, Integer tagId) {
        return new EvaluationTicket()
                .setOrderId(evaluateTicketDto.getOrderId())
                .setRemark(getNotNullValue(evaluateTicketDto.getRemark()))
                .setSourceName(evaluateTicketDto.getSourceName())
                .setSourcePhone(evaluateTicketDto.getSourcePhone())
                .setStar(evaluateTicketDto.getStar())
                .setTagId(tagId)
                .setTargetName(evaluateTicketDto.getTargetName())
                .setTargetPhone(evaluateTicketDto.getTargetPhone())
                .setTrackingId(evaluateTicketDto.getTrackingId());
    }

    private String getNotNullValue(String str) {
        return str == null ? "" : str;
    }

    private Integer getNotNullValue(Integer value) {
        return value == null ? Integer.valueOf(0) : value;
    }
}
