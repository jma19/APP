package me.ele.feedback.listener;

import com.rabbitmq.client.Channel;
import me.ele.contract.exception.ServiceException;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.feedback.Service.EvaluateDaoService;
import me.ele.feedback.api.dto.EvaluateTicketDto;
import me.ele.lpd.core.metric.MetricUtils;
import me.ele.lpd.core.util.JsonUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.ChannelAwareMessageListener;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by majun on 16/2/25.
 */
public class EvaluationListener implements ChannelAwareMessageListener {
    private final static Log logger = LogFactory.getLog(EvaluationListener.class);

    @Autowired
    private EvaluateDaoService evaluateDaoService;

    @Override
    public void onMessage(Message message, Channel channel) throws Exception {
        String jsonMessage = new String(message.getBody());
        logger.info("监听到增加评价消息jsonMessage={}", jsonMessage);
        try {
            long startTime = System.currentTimeMillis();
            EvaluateTicketDto evaluateTicketDto = JsonUtils.fromJson(jsonMessage, EvaluateTicketDto.class);
            evaluateDaoService.createEvaluateTickets(evaluateTicketDto);
            MetricUtils.recordTimeMetric(EvaluationListener.class, "createEvaluateTickets", startTime);
        } catch (ServiceException exp) {
            logger.error("访问数据库异常, msg={}", exp.getMessage());
        } catch (Exception e) {
            logger.error("evaluation插入失败, jsonMessage={}", jsonMessage, e);
        } finally {
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
        }
    }
}
