package me.ele.feedback.api;

import static me.ele.feedback.constant.ExceptionConstants.ACCEESS_DB_EXCEPTION;
import static me.ele.feedback.constant.ExceptionConstants.ALREADY_FEEDBACK_EXCEPTION;
import static me.ele.feedback.constant.ExceptionConstants.ILLEGAL_PARAMETER_EXCEPTION;
import static me.ele.feedback.constant.ExceptionConstants.NO_AUTH_EXCEPTION;
import static me.ele.feedback.constant.ExceptionConstants.SYSTEM_EXCEPTION;
import static me.ele.feedback.constant.PublicConstants.complainTypesMap;
import static me.ele.feedback.constant.PublicConstants.feedbackReasonsMap;
import static me.ele.feedback.constant.PublicConstants.productTypesMap;
import static me.ele.feedback.constant.PublicConstants.sourceMap;
import static me.ele.feedback.utils.ParameterChecker.isNull;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.stream.Collectors;

import me.ele.contract.exception.ServerException;
import me.ele.contract.exception.ServiceException;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.feedback.Service.AsyMsgSender;
import me.ele.feedback.Service.ShippingOrderService;
import me.ele.feedback.api.bean.FeedbackEntity;
import me.ele.feedback.api.dto.FeedbackDto;
import me.ele.feedback.api.dto.FeedbackTicketDto;
import me.ele.feedback.api.dto.UpdateFeedbackDto;
import me.ele.feedback.api.services.IFeedbackService;
import me.ele.feedback.dao.FeedbackServiceDao;
import me.ele.feedback.lib.sos.TShippingOrder;
import me.ele.feedback.utils.EmojiFilterUtils;
import me.ele.feedback.utils.TimeUtils;
import me.ele.lpd.core.metric.MetricUtils;
import me.ele.sla.common.util.Base64Util;
import me.ele.sla.common.util.SignUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/*
collection feedback information
 */
@Service
public class FeedbackService implements IFeedbackService {

    private static final String KEY = "efd4d064e6eb65f3ce820bbccdee843f";

    @Autowired
    private FeedbackServiceDao feedbackDao;

    @Autowired
    private ShippingOrderService shippingOrderService;

    @Autowired
    private AsyMsgSender feedbackAsySender;

    private static final Log logger = LogFactory.getLog(IFeedbackService.class);

    @Override
    public void updateFeedback(UpdateFeedbackDto updateFeedbackDto) throws ServiceException {
        logger.info("updateFeedback收到数据: updateFeedbackDto={}", updateFeedbackDto);
        if (null == updateFeedbackDto) {
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }
        try {
            feedbackDao.updateFeedback(updateFeedbackDto);
        } catch (Exception e) {
            logger.error("updateFeedback occurred an exception : ", e.getLocalizedMessage());
            throw ACCEESS_DB_EXCEPTION;
        }
    }

    @Override
    public void addFeedback(FeedbackDto feedbackDto) throws ServiceException {
        logger.info("addFeedback收到数据 feedbackDto={}", feedbackDto);
        long startTime = System.currentTimeMillis();
        if (null == feedbackDto
                || StringUtils.isBlank(feedbackDto.getComplaint_phone())
                || feedbackDto.getWaybill_num() < 0
                || feedbackDto.getTypes().size() <= 0) {
            logger.warn("缺少关键参数!!!");
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }

        if (!productTypesMap.keySet().contains(feedbackDto.getProduct_id()) ||
                !feedbackReasonsMap.keySet().containsAll(feedbackDto.getTypes())) {
            logger.warn("productId或者feedbackReason填写有误");
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }

        checkIfAlreadyFeedback(feedbackDto.getWaybill_num());

        feedbackDto.setComplaint_phone(Base64Util.decode(feedbackDto.getComplaint_phone().trim()));

        TShippingOrder tShippingOrder = shippingOrderService.getShippingOrder(feedbackDto.getWaybill_num());

        //phone check
        if (!isLegalPhone(feedbackDto, tShippingOrder)) {
            throw NO_AUTH_EXCEPTION;
        }

        try {
            feedbackDao.addFeedback(getFeedbackEntities(feedbackDto, tShippingOrder));
            MetricUtils.recordTimeMetric(FeedbackService.class, "addFeedback", startTime);
        } catch (Exception e) {
            logger.error("FeedbackService.addFeedback occured an exception : ", e.getLocalizedMessage());
            throw SYSTEM_EXCEPTION;
        }

    }

    private boolean isLegalPhone(FeedbackDto feedbackDto, TShippingOrder tShippingOrder) {
        return feedbackDto.getComplaint_phone().equals(tShippingOrder.getConsumer_info().getContact().getPrimary_phone())
                || feedbackDto.getComplaint_phone().equals(tShippingOrder.getConsumer_info().getContact().getSecond_phone());
    }


    private List<FeedbackEntity> getFeedbackEntities(FeedbackDto feedbackDto, TShippingOrder tShippingOrder) {


        feedbackDto.setContent(EmojiFilterUtils.filterEmoji(feedbackDto.getContent()));
        feedbackDto.setKnight_name(tShippingOrder.getDriver_info().getDriver_name());
        feedbackDto.setKnight_phone(tShippingOrder.getDriver_info().getDriver_phone());

        return feedbackDto.getTypes().stream()
                .map(value -> getFeedbackEntity(feedbackDto, value)).collect(Collectors.toList());

    }

    private FeedbackEntity getFeedbackEntity(FeedbackDto feedbackDto, Integer value) {
        FeedbackEntity feedbackEntity = new FeedbackEntity();
        feedbackEntity.setWaybill_num(feedbackDto.getWaybill_num());
        feedbackEntity.setProduct_id(feedbackDto.getProduct_id());
        feedbackEntity.setComplaint_phone(feedbackDto.getComplaint_phone());
        feedbackEntity.setKnight_name(feedbackDto.getKnight_name());
        feedbackEntity.setKnight_phone(feedbackDto.getKnight_phone());
        feedbackEntity.setType(value);
        feedbackEntity.setContent(feedbackDto.getContent());
        return feedbackEntity;
    }


    private void checkIfAlreadyFeedback(long waybill_num) throws ServiceException {
        boolean result;
        try {
            result = feedbackDao.getFeedbackCount(waybill_num) > 0;
        } catch (Exception exp) {
            logger.error("数据库异常,获取feedbackCount失败");
            throw ACCEESS_DB_EXCEPTION;
        }
        if (result) {
            throw ALREADY_FEEDBACK_EXCEPTION;
        }
    }

    @Override
    public List<Long> getWaybillNumByDateProduct(String date, Integer productId,
                                                 Integer page, String sign) throws ServiceException, ServerException {
        logger.debug("getWaybillNumByDateProduct收到数据, date: {}, productId: {}, page: {}, sign: {}", date, productId, page, sign);
        long startTime = System.currentTimeMillis();

        if (!TimeUtils.islegalFormatTime(date)) {
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }

        TreeMap<String, String> params = new TreeMap<>();
        params.put("date", date);
        params.put("productId", String.valueOf(productId));
        params.put("page", String.valueOf(page));
        boolean valid = SignUtil.checkSign(params, this.KEY, sign);

        if (!valid || page < 0) {
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }
        int pageSize = 500;
        int offset = pageSize * page;
        try {
            String ymdOfDate = TimeUtils.getYMDOfDate(date);
            List<Long> waybillNumByDateProduct = feedbackDao.getWaybillNumByDateProduct(ymdOfDate, TimeUtils.increaseOneDay(ymdOfDate), productId, offset, pageSize);
            MetricUtils.recordTimeMetric(FeedbackService.class, "getWaybillNumByDateProduct", startTime);
            return waybillNumByDateProduct;
        } catch (Exception exp) {
            logger.error("数据库异常,getWaybillNumByDateProduct失败", exp);
            throw ACCEESS_DB_EXCEPTION;
        }
    }

    @Override
    public List<Long> getWaybillNumByDateTypeProduct(String date, Integer productId, String types,
                                                     Integer page, String sign) throws ServiceException, ServerException {
        logger.debug("getWaybillNumByDateProduct收到数据, date: {}, productId: {}, page: {}, types: {}, sign: {}", date, productId, page, types, sign);
        if (!TimeUtils.islegalFormatTime(date)) {
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }
        long startTime = System.currentTimeMillis();

        TreeMap<String, String> params = new TreeMap<>();
        params.put("date", date);
        params.put("productId", String.valueOf(productId));
        params.put("page", String.valueOf(page));
        params.put("types", types);
        boolean valid = SignUtil.checkSign(params, this.KEY, sign);

        if (!valid || page < 0) {
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }
        int pageSize = 500;
        int offset = pageSize * page;
        try {
            List<Integer> typeList = new ArrayList<Integer>();
            String[] ts = types.split(",");
            for (String t : ts) {
                typeList.add(Integer.parseInt(t));
            }
            String ymdOfDate = TimeUtils.getYMDOfDate(date);
            List<Long> waybillNumByDateTypeProduct = feedbackDao.getWaybillNumByDateTypeProduct(ymdOfDate, TimeUtils.increaseOneDay(ymdOfDate), productId, typeList, offset, pageSize);
            MetricUtils.recordTimeMetric(FeedbackService.class, "getWaybillNumByDateTypeProduct", startTime);
            return waybillNumByDateTypeProduct;
        } catch (Exception exp) {
            logger.error("数据库异常,getWaybillNumByDateProduct失败", exp);
            throw ACCEESS_DB_EXCEPTION;
        }
    }

    @Override
    public int getCountByDateProduct(String date, int productId, String sign) throws ServiceException {
        logger.info("getCountByDateProduct收到数据, data={}, productId={},sign={}", date, productId, sign);
        if (!TimeUtils.islegalFormatTime(date)) {
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }
        TreeMap<String, String> params = new TreeMap<>();
        params.put("date", date);
        params.put("productId", String.valueOf(productId));

        boolean valid = SignUtil.checkSign(params, this.KEY, sign);

        if (!valid) {
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }
        try {
            String ymdOfDate = TimeUtils.getYMDOfDate(date);
            return feedbackDao.getCountByDateProduct(ymdOfDate, TimeUtils.increaseOneDay(ymdOfDate), productId);
        } catch (Exception exp) {
            logger.error("数据库异常,获取feedbackCount失败", exp);
            throw ACCEESS_DB_EXCEPTION;
        }
    }

    @Override
    public int getCountByDateTypeProduct(String date, int productId, String types, String sign) throws ServiceException {
        logger.info("getCountByDateProduct收到数据, data={}, productId={}, types={}, sign={}", date, productId, types, sign);
        if (!TimeUtils.islegalFormatTime(date)) {
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }
        TreeMap<String, String> params = new TreeMap<>();
        params.put("date", date);
        params.put("productId", String.valueOf(productId));
        params.put("types", types);

        boolean valid = SignUtil.checkSign(params, this.KEY, sign);

        if (!valid) {
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }
        try {
            List<Integer> typeList = new ArrayList<Integer>();
            String[] ts = types.split(",");
            for (String t : ts) {
                typeList.add(Integer.parseInt(t));
            }
            String ymdOfDate = TimeUtils.getYMDOfDate(date);
            return feedbackDao.getCountByDateTypeProduct(ymdOfDate, TimeUtils.increaseOneDay(ymdOfDate), productId, typeList);
        } catch (Exception exp) {
            logger.error("数据库异常,获取feedbackCount失败", exp);
            throw ACCEESS_DB_EXCEPTION;
        }
    }

    @Override
    public void createFeedbackTicket(FeedbackTicketDto feedbackTicket) throws ServiceException {
        logger.info("insertFeedback收到数据, 输入参数feedbackInsertDto={}", feedbackTicket);

        if (isNull(feedbackTicket) || isNull(feedbackTicket.getSourceId())
                || isNull(feedbackTicket.getProductId()) || isNull(feedbackTicket.getComplainType())
                || isNull(feedbackTicket.getComplainSource()) || isNull(feedbackTicket.getComplainAt())) {
            logger.info("缺失关键参数,参数校验为空,feedbackDao={}", feedbackTicket);
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }

        //非投诉平台
        if (feedbackTicket.getComplainType() != 6 && feedbackTicket.getComplainType() != 7) {
            if (isNull(feedbackTicket.getOrderId()) || isNull(feedbackTicket.getTrackingId())) {
                logger.info("orderId或trackingId为空, 参数检验失败, feedbackTicket={}", feedbackTicket);
                throw ILLEGAL_PARAMETER_EXCEPTION;
            }

            if (!sourceMap.containsKey(feedbackTicket.getSourceId()) && productTypesMap.containsKey(feedbackTicket.getProductId())
                    && complainTypesMap.containsKey(feedbackTicket.getComplainType())) {
                logger.info("渠道, 产品线,或是反馈/申诉类型有误, 参数校验失败,feedbackInsertDto={}", feedbackTicket);
                throw ILLEGAL_PARAMETER_EXCEPTION;
            }

            TShippingOrder tShippingOrder = shippingOrderService.getShippingOrder(feedbackTicket.getTrackingId());

            if (!tShippingOrder.getPlatform_info().getTracking_id().equals(feedbackTicket.getOrderId())) {
                logger.info("orderId有误, 输入orderId={},真实orderId={}", feedbackTicket.getOrderId(), tShippingOrder.getPlatform_info().getTracking_id());
                throw ILLEGAL_PARAMETER_EXCEPTION;
            }
        }

        feedbackTicket.setRemark(EmojiFilterUtils.filterEmoji(feedbackTicket.getRemark()));
        feedbackAsySender.sendAsyMessage("feedback.insert", feedbackTicket);
    }
}
