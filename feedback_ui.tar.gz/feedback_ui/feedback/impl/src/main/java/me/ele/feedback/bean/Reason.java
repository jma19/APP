package me.ele.feedback.bean;

/**
 * Created by majun on 16/1/26.
 */
public class Reason {
    private Integer reasonId;
    private String reasonName;

    public Integer getReasonId() {
        return reasonId;
    }

    public Reason setReasonId(Integer reasonId) {
        this.reasonId = reasonId;
        return this;
    }

    public String getReasonName() {
        return reasonName;
    }

    public Reason setReasonName(String reasonName) {
        this.reasonName = reasonName;
        return this;
    }

    @Override
    public String toString() {
        return "Reason{" +
                "reasonId=" + reasonId +
                ", reasonName='" + reasonName + '\'' +
                '}';
    }
}
