package me.ele.feedback.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

public class EmojiFilterUtils {

	/**
	 * 将emoji表情替换成?
	 * 
	 * @param source
	 * @return 过滤后的字符串
	 */
	public static boolean isExistEmoji(String source) {
		if (StringUtils.isNotBlank(source)) {
			String regEx = "[\\ud800\\udc00-\\udbff\\udfff\\ud800-\\udfff]";
			Pattern pattern = Pattern.compile(regEx);
			Matcher matcher = pattern.matcher(source);
			return matcher.find();
		}
		return false;

	}

	/**
	 * 将emoji表情替换成?
	 *
	 * @param source
	 * @return 过滤后的字符串
	 */
	public static String filterEmoji(String source) {
		if (StringUtils.isNotBlank(source)) {
			return source.replaceAll("[\\ud800\\udc00-\\udbff\\udfff\\ud800-\\udfff]", "?");
		}
		return source;
	}
}
