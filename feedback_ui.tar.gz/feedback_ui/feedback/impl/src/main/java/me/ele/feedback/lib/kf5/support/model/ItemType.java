package me.ele.feedback.lib.kf5.support.model;

public enum ItemType {
	
	TICKET;

}
