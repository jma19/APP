package me.ele.feedback.constant;

import me.ele.contract.exception.ServiceException;

/**
 * Created by majun on 16/1/19.
 * 1. 定义Exception Constant, 复用....
 * 2. 定义本系统errorCode
 */
public interface ExceptionConstants {

    ServiceException SYSTEM_EXCEPTION = new ServiceException("SYSTEM_ERROR", "系统异常，请稍后再试");
    ServiceException NO_AUTH_EXCEPTION = new ServiceException("NO_AUTH_ERROR", "您没有投诉此单的权限");
    ServiceException SHIPPING_ORDER_NOT_FOUND_EXCEPTION = new ServiceException("SHIPPING_ORDER_NOT_FOUND_ERROR", "运单不存在!!!");
    ServiceException ILLEGAL_PARAMETER_EXCEPTION = new ServiceException("ILLEGAL_PARAMETERS_ERROR", "参数错误!!!");
    ServiceException ALREADY_FEEDBACK_EXCEPTION = new ServiceException("ALREADY_FEEDBACK_ERROR", "您已反馈成功,请勿重复点击!!!");

    ServiceException ACCEESS_DB_EXCEPTION = new ServiceException("SYSTEM_ERROR", "访问数据异常");
    ServiceException UNKNOWN_EXCEPTION = new ServiceException("UNKNOWN_ERROR", "未知异常");
    ServiceException APOLLO_MGT_ACCESS_EXCEPTION = new ServiceException("APOLLO_MGT_ACCESS_ERROR", "调用Apollo获取订单失败");



}
