package me.ele.feedback.lib.sos;
public enum PayMethod {
    PAY_OFFLINE(1), // 现金
    PAY_ONLINE(2); // 在线付款

    private final int value;

    private PayMethod(int value) {
        this.value = value;
    }
    
    public int getValue() {
    	return value;
    }

    public static PayMethod get(int value) {
        for (PayMethod payMethod : values()) {
            if (payMethod.value == value) {
                return payMethod;
            }
        }
        return null;
    }
}
