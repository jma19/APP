package me.ele.feedback.listener;

import com.google.common.collect.Lists;
import com.rabbitmq.client.Channel;
import me.ele.contract.exception.ServiceException;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.feedback.Service.FeedbackDaoService;
import me.ele.feedback.Service.Kf5Service;
import me.ele.feedback.api.bean.ComplainObject;
import me.ele.feedback.api.dto.FeedbackTicketDto;
import me.ele.feedback.bean.FeedbackTicket;
import me.ele.feedback.bean.SuggestionTicket;
import me.ele.feedback.lib.kf5.support.model.Ticket;
import me.ele.lpd.core.util.JsonUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.ChannelAwareMessageListener;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by majun on 16/1/25.
 */
public class FeedbackListener implements ChannelAwareMessageListener {

    private final static Log logger = LogFactory.getLog(FeedbackListener.class);

    @Autowired
    private FeedbackDaoService feedbackDaoService;

    @Autowired
    private Kf5Service kf5Service;

    @Override
    public void onMessage(Message message, Channel channel) throws Exception {
        String jsonMessage = new String(message.getBody());
        logger.info("监听到feedback增加消息jsonMessage={}", jsonMessage);
        try {
            //发送消息
            FeedbackTicketDto feedbackInsertDto = JsonUtils.fromJson(jsonMessage, FeedbackTicketDto.class);
            //6 为投诉平台
            if (feedbackInsertDto.getComplainType() != 6) {
                List<FeedbackTicket> feedbackList = getFeedbackList(feedbackInsertDto);
                feedbackDaoService.createFeedbacks(feedbackList);
            } else {
                feedbackDaoService.createSuggestion(getSuggestionTicket(feedbackInsertDto));
            }

            Ticket ticket = kf5Service.createTicket(feedbackInsertDto);
            if (ticket != null) {
                logger.info("调用KF5工单系统成功!!!, ticket={}", ticket);
            } else {
                logger.info("调用KF5工单系统失败,生成工单为空!!!");
            }
        } catch (ServiceException exp) {
            logger.error("插入数据库失败, msg={}", exp.getMessage());
        } catch (Exception e) {
            logger.error("feedback插入失败, jsonMessage={}", jsonMessage, e);
        } finally {
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
        }
    }

    private List<FeedbackTicket> getFeedbackList(FeedbackTicketDto feedbackInsertDto) {
        List<Integer> complainReasonIds = feedbackInsertDto.getComplainReasonIds();

        if (complainReasonIds == null || complainReasonIds.isEmpty()) {
            return Lists.newArrayList(getFeedbackTicket(feedbackInsertDto, 0));
        }
        return complainReasonIds.stream().map(value -> getFeedbackTicket(feedbackInsertDto, value))
                .collect(Collectors.toList());
    }

    private SuggestionTicket getSuggestionTicket(FeedbackTicketDto feedbackTicketDto){
        return new SuggestionTicket()
                .setProductId(feedbackTicketDto.getProductId())
                .setSourceId(feedbackTicketDto.getSourceId())
                .setRemark(feedbackTicketDto.getRemark())
                .setSugAt(getTimestamp(feedbackTicketDto.getComplainAt()))
                .setSugSourceId(getComplainId(feedbackTicketDto.getComplainSource()))
                .setSugSourceName(getComplainName(feedbackTicketDto.getComplainSource()))
                .setSugSourcePhone(getComplainPhone(feedbackTicketDto.getComplainSource()))
                .setSugTargetId(getComplainId(feedbackTicketDto.getComplainTarget()))
                .setSugTargetName(getComplainName(feedbackTicketDto.getComplainTarget()))
                .setSugTargetPhone(getComplainPhone(feedbackTicketDto.getComplainTarget()));

    }

    private FeedbackTicket getFeedbackTicket(FeedbackTicketDto feedbackInsertDto, Integer reasonId) {
        return new FeedbackTicket()
                .setSourceId(feedbackInsertDto.getSourceId())
                .setProductId(feedbackInsertDto.getProductId())
                .setComplainType(feedbackInsertDto.getComplainType())
                .setComplainReasonId(getNotNullComponent(reasonId))
                .setTrackingId(getNotNullComponent(feedbackInsertDto.getTrackingId()))
                .setOrderId(getNotNullComponent(feedbackInsertDto.getOrderId()))
                .setComplainSourceId(getComplainId(feedbackInsertDto.getComplainSource()))
                .setComplainSourceName(getComplainName(feedbackInsertDto.getComplainSource()))
                .setComplainSourcePhone(getComplainPhone(feedbackInsertDto.getComplainSource()))
                .setComplainTargetId(getComplainId(feedbackInsertDto.getComplainTarget()))
                .setComplainTargetName(getComplainName(feedbackInsertDto.getComplainTarget()))
                .setComplainTargetPhone(getComplainPhone(feedbackInsertDto.getComplainTarget()))
                .setComplainAt(getTimestamp(feedbackInsertDto.getComplainAt()))
                .setSolvedAt(getTimestamp(feedbackInsertDto.getSolvedAt()))
                .setRemark(getNotNullComponent(feedbackInsertDto.getRemark()));
    }

    private String getComplainName(ComplainObject complainObject) {
        return complainObject == null ? "" : complainObject.getName();
    }

    private String getComplainPhone(ComplainObject complainObject) {
        return complainObject == null ? "" : complainObject.getPhone();
    }

    private Long getComplainId(ComplainObject complainObject) {
        return complainObject == null ? 0 : complainObject.getId();
    }


    private String getNotNullComponent(String comp) {
        return comp == null ? "" : comp;
    }

    private Long getNotNullComponent(Long comp) {
        return comp == null ? Long.valueOf(0) : comp;
    }

    private Integer getNotNullComponent(Integer comp) {
        return comp == null ? Integer.valueOf(0) : comp;
    }


    private Timestamp getTimestamp(Long time) {

        return time == null || time == 0 ? new Timestamp(System.currentTimeMillis()) : new Timestamp(time);
    }
}
