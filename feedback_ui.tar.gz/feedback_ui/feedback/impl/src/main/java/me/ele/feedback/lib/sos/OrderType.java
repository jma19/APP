package me.ele.feedback.lib.sos;
public enum OrderType {
    NORMAL_ORDER(1), // 正常订单，立即取货送货
    SCHEDULE_ORDER(2); // 预订单，预约配送

    private final int value;

    private OrderType(int value) {
        this.value = value;
    }
    
    public int getValue() {
    	return value;
    }

    public static OrderType get(int value) {
        for (OrderType payMethod : values()) {
            if (payMethod.value == value) {
                return payMethod;
            }
        }
        return null;
    }
}
