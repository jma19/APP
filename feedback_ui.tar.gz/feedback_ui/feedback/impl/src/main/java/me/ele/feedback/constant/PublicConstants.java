package me.ele.feedback.constant;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import com.google.common.collect.Lists;
import me.ele.feedback.api.bean.TagEntity;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by majun on 16/1/19.
 */
public interface PublicConstants {

    Map<Integer, String> sourceMap = new HashMap<Integer, String>() {
        private static final long serialVersionUID = 1L;

        {
            put(1, "众包APP");
            put(2, "配送完成短信反馈");
            put(3, "物流中心app");
        }
    };

    Map<Integer, String> productTypesMap = new HashMap<Integer, String>() {
        private static final long serialVersionUID = 1L;

        {
            put(1, "众包");
            put(2, "团队");
            put(3, "bod");
        }
    };


    Map<Integer, String> complainTypesMap = new HashMap<Integer, String>() {
        private static final long serialVersionUID = 1L;

        {
            put(1, "骑手投诉商户");
            put(2, "商户投诉骑手");
            put(3, "用户投诉骑手");
            put(4, "骑手申诉");
            put(5, "商户申诉");
            put(6, "投诉平台");
            put(7, "其他问题");
        }
    };

    Map<Integer, String> feedbackReasonsMap = new HashMap<Integer, String>() {

        private static final long serialVersionUID = 1L;

        {
            put(1, "配送速度慢");
            put(2, "菜品洒汤了");
            put(3, "配送员态度差");
            put(4, "没有收到餐");
            put(5, "其他");

            put(6, "商户不让取餐");
            put(7, "商户取消配送");
            put(8, "商户已将餐品送走");
            put(9, "商户态度恶劣");
            put(10, "商户定位地址错位导致错跑");
            put(11, "蜂鸟团队配送员使用众包抢单配送");
            put(12, "商户将订单给达达");
            put(13,"出餐慢");


            put(31, "态度恶劣");
            put(32, "诋毁商户或平台声誉");
            put(33, "用户未收到餐品");
            put(34, "未保持餐品完整");
            put(35, "提前点击送达导致投诉");
            put(36, "标记异常不进行配送");
            put(37, "偷取取餐码, 虚假确认配送");
            put(38, "抢单后长时间未取餐");
            put(39, "抢单后长时间未送达");
            put(40, "不进行配送,电联用户让用户退单");
            put(41, "额外收取用户钱款");
            put(42, "不配合取证调查(1.拒绝回访电话 2. 虚假证明 3. 对客服态度恶劣)");
            put(43, "配送问题导致用户退单");


            put(45, "警告申诉");
            put(46, "拉黑申诉");
            put(47, "疑似欺诈单申诉");
            put(48, "金银铜等级申诉");

            put(61, "调度管理");
            put(62, "账户信息");
            put(63, "结算");
            put(64, "订单状态");
            put(65, "业务咨询");
        }
    };

    Map<Integer, String> userEvaDriverContentMap = new HashMap<Integer, String>() {
        private static final long serialVersionUID = 1L;

        {
            put(1, "提前点击确认送达");
            put(2, "未收到餐");
            put(3, "服务态度差");
            put(4, "额外收费");
            put(5, "送错餐了");
            put(6, "餐品缺失或洒汤");
            put(7, "送餐速度慢");
            put(8, "未穿制服");

            put(9, "速度快");
            put(10, "餐品完整");
            put(11, "服务态度好");
            put(12, "颜值爆表");
            put(13, "提供额外帮助");
            put(14, "制服整洁");
        }
    };


    Supplier<List<TagEntity>> tagSuppliers = Suppliers.memoize((com.google.common.base.Supplier<List<TagEntity>>) () -> {
        List<TagEntity> evaluationTags = Lists.newArrayList();
        for (int star = 1; star <= 3; star++) {
            for (int tagId = 1; tagId <= 8; tagId++) {
                evaluationTags.add(new TagEntity(tagId, star, userEvaDriverContentMap.get(tagId)));
            }
        }

        for (int star = 4; star <= 5; star++) {
            for (int tagId = 9; tagId <= 14; tagId++) {
                evaluationTags.add(new TagEntity(tagId, star, userEvaDriverContentMap.get(tagId)));
            }
        }
        return evaluationTags;
    });

}
