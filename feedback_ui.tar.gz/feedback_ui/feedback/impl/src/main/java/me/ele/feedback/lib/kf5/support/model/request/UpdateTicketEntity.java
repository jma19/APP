package me.ele.feedback.lib.kf5.support.model.request;

/**
 * Created by majun on 16/1/19.
 */
public class UpdateTicketEntity {
    private UpdateTicketBody ticket;

    public UpdateTicketBody getTicket() {
        return ticket;
    }

    public UpdateTicketEntity setTicket(UpdateTicketBody ticket) {
        this.ticket = ticket;
        return this;
    }

    @Override
    public String toString() {
        return "UpdateTicketEntity{" +
                "ticket=" + ticket +
                '}';
    }
}
