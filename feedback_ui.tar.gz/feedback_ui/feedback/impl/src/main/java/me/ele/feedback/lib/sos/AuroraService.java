package me.ele.feedback.lib.sos;
import java.util.List;

public interface AuroraService {
    long platform_push(TOrder order) throws AuroraUserException, AuroraSystemException, AuroraUnknownException;

    boolean platform_process(long tracking_id, TProcessInfo process_info) throws AuroraUserException, AuroraSystemException, AuroraUnknownException;

    long carrier_push(TMiniShippingOrder shipping_order) throws AuroraUserException, AuroraSystemException, AuroraUnknownException;

    boolean carrier_process(long tracking_id, TProcessInfo process_info) throws AuroraUserException, AuroraSystemException, AuroraUnknownException;

    boolean carrier_process_by_platform(int platform_id, String platform_tracking_idT, TProcessInfo process_info) throws AuroraUserException,
            AuroraSystemException, AuroraUnknownException;

    List<TOrderDetailItem> get_order_detail(long tracking_id) throws AuroraUserException, AuroraSystemException, AuroraUnknownException;

    TShippingOrder get_shipping_order(long tracking_id) throws AuroraUserException, AuroraSystemException, AuroraUnknownException;

    TShippingOrder get_shipping_order_by_platform(int platform_id, String platform_tracking_id) throws AuroraUserException, AuroraSystemException,
            AuroraUnknownException;

    TCarrierDetail get_carrier_by_code(String carrier_code) throws AuroraUserException, AuroraSystemException, AuroraUnknownException;

    TCarrierDetail get_carrier(int carrier_id) throws AuroraUserException, AuroraSystemException, AuroraUnknownException;
}
