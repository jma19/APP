package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TCarrier {
    private @Index(1) int carrier_id;
    private @Index(2) String carrier_name;
    private @Index(3) String carrier_tracking_id;

    public int getCarrier_id() {
        return carrier_id;
    }

    public void setCarrier_id(int carrier_id) {
        this.carrier_id = carrier_id;
    }

    public String getCarrier_name() {
        return carrier_name;
    }

    public void setCarrier_name(String carrier_name) {
        this.carrier_name = carrier_name;
    }

    public String getCarrier_tracking_id() {
        return carrier_tracking_id;
    }

    public void setCarrier_tracking_id(String carrier_tracking_id) {
        this.carrier_tracking_id = carrier_tracking_id;
    }
}
