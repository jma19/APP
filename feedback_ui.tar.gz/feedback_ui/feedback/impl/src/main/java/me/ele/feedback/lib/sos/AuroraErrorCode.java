package me.ele.feedback.lib.sos;
public enum AuroraErrorCode implements org.apache.thrift.TEnum {
  UNKNOWN_ERROR(0),
  PONG_NOT_FOUND(1),
  SHIPPING_ORDER_NOT_FOUND(2),
  SHIPPING_ORDER_STATE_CANT_PROCESS(3),
  SHIPPING_ORDER_INVALID_ATTRIBUTE(5),
  SHIPPING_ORDER_ALREADY_EXIST(6),
  SHIPPING_ORDER_REASON_CODE_CANT_PROCESS(7),
  SHIPPING_ORDER_CALLCED_BY_CARRIER(8),
  MERCHANT_NOT_FOUND(9),
  CARRIER_NOT_FOUND(10),
  MERCHANT_CANCEL_TOO_MUCH(11),
  DATABASE_ERROR(999);

  private final int value;

  private AuroraErrorCode(int value) {
    this.value = value;
  }

  public int getValue() {
    return value;
  }

  public static AuroraErrorCode findByValue(int value) { 
    switch (value) {
      case 0:
        return UNKNOWN_ERROR;
      case 1:
        return PONG_NOT_FOUND;
      case 2:
        return SHIPPING_ORDER_NOT_FOUND;
      case 3:
        return SHIPPING_ORDER_STATE_CANT_PROCESS;
      case 5:
        return SHIPPING_ORDER_INVALID_ATTRIBUTE;
      case 6:
        return SHIPPING_ORDER_ALREADY_EXIST;
      case 7:
        return SHIPPING_ORDER_REASON_CODE_CANT_PROCESS;
      case 8:
        return SHIPPING_ORDER_CALLCED_BY_CARRIER;
      case 9:
        return MERCHANT_NOT_FOUND;
      case 10:
        return CARRIER_NOT_FOUND;
      case 11:
    	  return MERCHANT_CANCEL_TOO_MUCH;
      case 999:
        return DATABASE_ERROR;
      default:
        return null;
    }
  }
}
