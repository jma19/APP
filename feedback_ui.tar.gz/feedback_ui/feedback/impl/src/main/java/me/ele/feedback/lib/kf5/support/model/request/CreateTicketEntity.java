package me.ele.feedback.lib.kf5.support.model.request;

/**
 * Created by majun on 16/1/19.
 */
public class CreateTicketEntity {
    private CreateTicketBody ticket;

    public CreateTicketBody getTicket() {
        return ticket;
    }

    public CreateTicketEntity setTicket(CreateTicketBody ticket) {
        this.ticket = ticket;
        return this;
    }

    @Override
    public String toString() {
        return "CreateTicketEntity{" +
                "ticket=" + ticket +
                '}';
    }
}
