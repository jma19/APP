package me.ele.feedback.lib.kf5.support.model;

public class CustomField {

	private String name;
	
	private String  value;

	public String getName() {
		return name;
	}

	public CustomField setName(String name) {
		this.name = name;
		return this;
	}

	public String getValue() {
		return value;
	}

	public CustomField setValue(String value) {
		this.value = value;
		return this;
	}

	@Override
	public String toString() {
		return "CustomField{" +
				"name='" + name + '\'' +
				", value='" + value + '\'' +
				'}';
	}
}
