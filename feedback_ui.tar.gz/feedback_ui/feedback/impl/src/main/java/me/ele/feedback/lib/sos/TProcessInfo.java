package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TProcessInfo {
    private @Index(1) int to_state;
    private @Index(2) int reason_code;
    private @Index(3) String remark;
    private @Index(4) TCarrier carrier_info;
    private @Index(5) TCarrierDriver driver_info;
    private @Index(6) long occured_time;
    private @Index(7) TLocation location;
    private @Index(8) String remark_code;

    public int getTo_state() {
        return to_state;
    }

    public void setTo_state(int to_state) {
        this.to_state = to_state;
    }

    public int getReason_code() {
        return reason_code;
    }

    public void setReason_code(int reason_code) {
        this.reason_code = reason_code;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public TCarrier getCarrier_info() {
        return carrier_info;
    }

    public void setCarrier_info(TCarrier carrier_info) {
        this.carrier_info = carrier_info;
    }

    public TCarrierDriver getDriver_info() {
        return driver_info;
    }

    public void setDriver_info(TCarrierDriver driver_info) {
        this.driver_info = driver_info;
    }

    public long getOccured_time() {
        return occured_time;
    }

    public void setOccured_time(long occured_time) {
        this.occured_time = occured_time;
    }

    public TLocation getLocation() {
        return location;
    }

    public void setLocation(TLocation location) {
        this.location = location;
    }

    public String getRemark_code() {
        return remark_code;
    }

    public void setRemark_code(String remark_code) {
        this.remark_code = remark_code;
    }
}
