package me.ele.feedback.lib.kf5.support.model;

public class CustomFieldOption extends CustomField {

}
