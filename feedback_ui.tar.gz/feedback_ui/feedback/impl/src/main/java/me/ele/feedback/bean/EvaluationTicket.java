package me.ele.feedback.bean;



/**
 * Created by majun on 16/2/25.
 */
public class EvaluationTicket {

    private Integer star;
    private Integer tagId;
    private String orderId;
    private Long trackingId;
    private String sourceName;
    private String sourcePhone;
    private String targetName;
    private String targetPhone;
    private String remark;


    public String getOrderId() {
        return orderId;
    }

    public EvaluationTicket setOrderId(String orderId) {
        this.orderId = orderId;
        return this;
    }

    public String getRemark() {
        return remark;
    }

    public EvaluationTicket setRemark(String remark) {
        this.remark = remark;
        return this;

    }

    public String getSourceName() {
        return sourceName;
    }

    public EvaluationTicket setSourceName(String sourceName) {
        this.sourceName = sourceName;
        return this;

    }

    public String getSourcePhone() {
        return sourcePhone;
    }

    public EvaluationTicket setSourcePhone(String sourcePhone) {
        this.sourcePhone = sourcePhone;
        return this;

    }

    public Integer getStar() {
        return star;
    }

    public EvaluationTicket setStar(Integer star) {
        this.star = star;
        return this;

    }

    public Integer getTagId() {
        return tagId;
    }

    public EvaluationTicket setTagId(Integer tagId) {
        this.tagId = tagId;
        return this;

    }

    public String getTargetName() {
        return targetName;
    }

    public EvaluationTicket setTargetName(String targetName) {
        this.targetName = targetName;
        return this;

    }

    public String getTargetPhone() {
        return targetPhone;
    }

    public EvaluationTicket setTargetPhone(String targetPhone) {
        this.targetPhone = targetPhone;
        return this;

    }

    public Long getTrackingId() {
        return trackingId;
    }

    public EvaluationTicket setTrackingId(Long trackingId) {
        this.trackingId = trackingId;
        return this;

    }

    @Override
    public String toString() {
        return "EvaluationTicket{" +
                "orderId='" + orderId + '\'' +
                ", star=" + star +
                ", tagId=" + tagId +
                ", trackingId=" + trackingId +
                ", sourceName='" + sourceName + '\'' +
                ", sourcePhone='" + sourcePhone + '\'' +
                ", targetName='" + targetName + '\'' +
                ", targetPhone='" + targetPhone + '\'' +
                ", remark='" + remark + '\'' +
                '}';
    }
}
