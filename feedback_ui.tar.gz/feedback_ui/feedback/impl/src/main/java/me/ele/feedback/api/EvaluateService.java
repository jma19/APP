package me.ele.feedback.api;

import me.ele.contract.exception.ServiceException;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.feedback.Service.ApolloMgtService;
import me.ele.feedback.Service.AsyMsgSender;
import me.ele.feedback.api.bean.TagEntity;
import me.ele.feedback.api.dto.EvaluateTicketDto;
import me.ele.feedback.api.services.IEvaluateService;
import me.ele.feedback.constant.PublicConstants;
import me.ele.lpd.core.metric.MetricUtils;
import me.ele.managementService.model.DTO.OrderSourceCode;
import me.ele.managementService.model.bean.ShippingOrderDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static me.ele.feedback.constant.ExceptionConstants.ILLEGAL_PARAMETER_EXCEPTION;
import static me.ele.feedback.constant.ExceptionConstants.SHIPPING_ORDER_NOT_FOUND_EXCEPTION;
import static me.ele.feedback.utils.ParameterChecker.isNull;

/**
 * Created by majun on 16/2/23.
 */
@Service
public class EvaluateService implements IEvaluateService {

    private static final Log logger = LogFactory.getLog(EvaluateService.class);

    @Autowired
    private ApolloMgtService apolloMgtService;

    @Autowired
    private AsyMsgSender asyMsgSender;

    @Override
    public List<TagEntity> getCustomerEvaDriverTags(Integer star, String orderId) throws ServiceException {
        logger.info("getCustomerEvaDriverTags收到数据 star={}, orderId={}", star, orderId);
        long startTime = System.currentTimeMillis();
        if (isNull(orderId)) {
            logger.warn("缺少关键参数!!!");
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }
        List<TagEntity> tagEntities = PublicConstants.tagSuppliers.get();
        MetricUtils.recordTimeMetric(EvaluateService.class,"createEvaTicket",startTime);
        return tagEntities;
    }

    //用户评价骑手
    @Override
    public void createEvaTicket(EvaluateTicketDto evaluateTicketDto) throws ServiceException {

        logger.info("createEvaTicket收到数据 evaluateTicket={}", evaluateTicketDto);
        long startTime = System.currentTimeMillis();
        if (isNull(evaluateTicketDto) || isNull(evaluateTicketDto.getOrderId())
                || isNull(evaluateTicketDto.getSourceName())
                || isNull(evaluateTicketDto.getSourcePhone())
                || isNull(evaluateTicketDto.getStar())
                || isNull(evaluateTicketDto.getTargetName())
                || isNull(evaluateTicketDto.getTargetPhone())
                || evaluateTicketDto.getStar() > 5
                || !PublicConstants.userEvaDriverContentMap.keySet().containsAll(evaluateTicketDto.getTagIds())) {
            logger.warn("参数校验失败, 关键参数有误, evaluateTicketDto={}!!!", evaluateTicketDto);
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }

        //调用apollo进行数据校验
        ShippingOrderDetail shippingOrderDetail = apolloMgtService.getShippingOrderDetail(OrderSourceCode.ELEME.getValue(), evaluateTicketDto.getOrderId());

        if(isNull(shippingOrderDetail)){
            throw SHIPPING_ORDER_NOT_FOUND_EXCEPTION;
        }

        //校验用户手机号和骑手手机号
        if (!evaluateTicketDto.getSourcePhone().equals(shippingOrderDetail.getCustomerMobile()) ||
                !evaluateTicketDto.getTargetPhone().equals(shippingOrderDetail.getCarrierDriverPhone())) {
            logger.warn("用户或骑手信息和Apollo获取的信息不一致, evaluateTicketDto={},shippingOrderDetail={} ", evaluateTicketDto, evaluateTicketDto);
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }
        evaluateTicketDto.setTrackingId(shippingOrderDetail.getTrackingId());
        asyMsgSender.sendAsyMessage("evaluation.insert", evaluateTicketDto);
        MetricUtils.recordTimeMetric(EvaluateService.class,"createEvaTicket",startTime);
    }


}
