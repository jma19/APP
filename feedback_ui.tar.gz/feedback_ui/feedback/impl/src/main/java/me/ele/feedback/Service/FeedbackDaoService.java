package me.ele.feedback.Service;

import me.ele.contract.exception.ServiceException;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.feedback.bean.FeedbackTicket;
import me.ele.feedback.bean.SuggestionTicket;
import me.ele.feedback.constant.ExceptionConstants;
import me.ele.feedback.dao.FeedbackServiceDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by majun on 16/1/25.
 */
@Service
public class FeedbackDaoService {
    private final static Log logger = LogFactory.getLog(FeedbackDaoService.class);

    @Autowired
    private FeedbackServiceDao feedbackDao;

    public void createFeedbacks(List<FeedbackTicket> feedbackList) throws ServiceException {
        try {
            logger.info("添加feedbackList,feedbackList={} ", feedbackList);
            feedbackDao.createFeedbackTickets(feedbackList);
        } catch (Exception exp) {
            logger.error("调用数据库异常!!!", exp);
            throw ExceptionConstants.ACCEESS_DB_EXCEPTION;
        }
    }

    public void createSuggestion(SuggestionTicket suggstionTicket) throws ServiceException {
        try {
            logger.info("添加suggestionTicket信息, suggestionTicket={} ", suggstionTicket);
            feedbackDao.createSuggestionTicket(suggstionTicket);
        } catch (Exception exp) {
            logger.error("调用数据库异常, 创建suggstionTicket失败!!!", exp);
            throw ExceptionConstants.ACCEESS_DB_EXCEPTION;
        }
    }
}
