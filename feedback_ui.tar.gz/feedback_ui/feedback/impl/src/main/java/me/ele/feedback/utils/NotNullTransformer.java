package me.ele.feedback.utils;

/**
 * Created by majun on 16/2/29.
 */
public class NotNullTransformer {

    public static String getNotNullComponent(String comp) {
        return comp == null ? "" : comp;
    }

    public static Long getNotNullComponent(Long comp) {
        return comp == null ? Long.valueOf(0) : comp;
    }

    public static Integer getNotNullComponent(Integer comp) {
        return comp == null ? Integer.valueOf(0) : comp;
    }

}
