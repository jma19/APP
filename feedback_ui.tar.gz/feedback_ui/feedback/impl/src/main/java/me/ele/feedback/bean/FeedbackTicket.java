package me.ele.feedback.bean;

import java.sql.Timestamp;

/**
 * Created by majun on 16/1/25.
 */
public class FeedbackTicket {
    
    private Integer sourceId;
    private Integer productId;
    private Integer complainType;
    private Integer complainReasonId;
    private Long trackingId;
    private String orderId ;
    private Long  complainSourceId;
    private String complainSourceName;
    private String complainSourcePhone;

    private Long  complainTargetId;
    private String complainTargetName;
    private String complainTargetPhone;
    private Timestamp complainAt;
    private Timestamp solvedAt;
    private String remark;

    public Integer getSourceId() {
        return sourceId;
    }

    public FeedbackTicket setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
        return this;
    }

    public Timestamp getComplainAt() {
        return complainAt;
    }

    public FeedbackTicket setComplainAt(Timestamp complainAt) {
        this.complainAt = complainAt;
        return this;
    }

    public Integer getComplainReasonId() {
        return complainReasonId;
    }

    public FeedbackTicket setComplainReasonId(Integer complainReasonId) {
        this.complainReasonId = complainReasonId;
        return this;
    }

    public Long getComplainSourceId() {
        return complainSourceId;
    }

    public FeedbackTicket setComplainSourceId(Long complainSourceId) {
        this.complainSourceId = complainSourceId;
        return this;

    }

    public String getComplainSourceName() {
        return complainSourceName;
    }

    public FeedbackTicket setComplainSourceName(String complainSourceName) {
        this.complainSourceName = complainSourceName;
        return this;

    }

    public String getComplainSourcePhone() {
        return complainSourcePhone;
    }

    public FeedbackTicket setComplainSourcePhone(String complainSourcePhone) {
        this.complainSourcePhone = complainSourcePhone;
        return this;
    }

    public Long getComplainTargetId() {
        return complainTargetId;
    }

    public FeedbackTicket setComplainTargetId(Long complainTargetId) {
        this.complainTargetId = complainTargetId;
        return this;
    }

    public String getComplainTargetName() {
        return complainTargetName;
    }

    public FeedbackTicket setComplainTargetName(String complainTargetName) {
        this.complainTargetName = complainTargetName;
        return this;
    }

    public String getComplainTargetPhone() {
        return complainTargetPhone;
    }

    public FeedbackTicket setComplainTargetPhone(String complainTargetPhone) {
        this.complainTargetPhone = complainTargetPhone;
        return this;
    }

    public Integer getComplainType() {
        return complainType;
    }

    public FeedbackTicket setComplainType(Integer complainType) {
        this.complainType = complainType;
        return this;
    }

    public String getOrderId() {
        return orderId;
    }

    public FeedbackTicket setOrderId(String orderId) {
        this.orderId = orderId;
        return this;
    }

    public Integer getProductId() {
        return productId;
    }

    public FeedbackTicket setProductId(Integer productId) {
        this.productId = productId;
        return this;
    }

    public String getRemark() {
        return remark;
    }

    public FeedbackTicket setRemark(String remark) {
        this.remark = remark;
        return this;
    }

    public Timestamp getSolvedAt() {
        return solvedAt;
    }

    public FeedbackTicket setSolvedAt(Timestamp solvedAt) {
        this.solvedAt = solvedAt;
        return this;
    }

    public Long getTrackingId() {
        return trackingId;
    }

    public FeedbackTicket setTrackingId(Long trackingId) {
        this.trackingId = trackingId;
        return this;
    }

    @Override
    public String toString() {
        return "FeedbackTicket{" +
                "complainAt=" + complainAt +
                ", sourceId=" + sourceId +
                ", productId=" + productId +
                ", ComplainType=" + complainType +
                ", complainReasonId=" + complainReasonId +
                ", trackingId=" + trackingId +
                ", orderId='" + orderId + '\'' +
                ", complainSourceId=" + complainSourceId +
                ", complainSourceName='" + complainSourceName + '\'' +
                ", complainSourcePhone='" + complainSourcePhone + '\'' +
                ", complainTargetId=" + complainTargetId +
                ", complainTargetName='" + complainTargetName + '\'' +
                ", complainTargetPhone='" + complainTargetPhone + '\'' +
                ", solvedAt=" + solvedAt +
                ", remark" + remark + '\'' +
                '}';
    }
}

