package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TAddress {
    private @Index(1) String text;
    private @Index(2) String district;
    private @Index(3) String city_name;
    private @Index(4) String city_code;
    private @Index(5) short city_id;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public short getCity_id() {
        return city_id;
    }

    public void setCity_id(short city_id) {
        this.city_id = city_id;
    }
}
