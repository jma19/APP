package me.ele.feedback.Service;

import me.ele.contract.exception.ServiceException;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.feedback.constant.ExceptionConstants;
import me.ele.feedback.utils.ClientUtils;
import me.ele.managementService.api.ShippingOrderSearchService;
import me.ele.managementService.model.bean.ShippingOrderDetail;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * Created by majun on 16/2/26.
 */
@Service
public class ApolloMgtService {

    private ShippingOrderSearchService shippingOrderSearchService;

    private final static Log logger = LogFactory.getLog(ApolloMgtService.class);

    @PostConstruct
    public void initService() throws ServiceException {
        this.shippingOrderSearchService = ClientUtils.getClient(ShippingOrderSearchService.class);
    }

    public ShippingOrderDetail getShippingOrderDetail(Integer sourceId, String orderId) throws ServiceException {

        try {
            return shippingOrderSearchService.getShippingOrderDetail(sourceId, orderId);
        } catch (ServiceException exp) {
            logger.error("调用apollo mgt模块获取订单信息失败, orderId={}", orderId, exp);
            throw ExceptionConstants.APOLLO_MGT_ACCESS_EXCEPTION;
        }

    }

}
