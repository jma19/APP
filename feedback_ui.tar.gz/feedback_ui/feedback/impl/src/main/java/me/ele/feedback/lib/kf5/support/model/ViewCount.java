package me.ele.feedback.lib.kf5.support.model;

public class ViewCount {

	private int view_id; //����id
	
	private String url; //��Ӧ��Դurl
	
	private int count; //��������

	public int getView_id() {
		return view_id;
	}

	public void setView_id(int view_id) {
		this.view_id = view_id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
}
