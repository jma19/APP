package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TShippingOption {
    /**
     * @see {@link OrderType}
     */
    private @Index(1) int order_type;
    private @Index(2) long schedule_delivery_time;
    private @Index(3) long promised_delivery_time;
    private @Index(4) boolean is_invoiced;
    private @Index(5) String invoice_title;
    private @Index(6) double freight;
    private @Index(7) int assign_type;
    private @Index(8) int pre_carrier_id;
    private @Index(9) String pre_carrier_attr;
    private @Index(10) int product_id;

    public int getOrder_type() {
        return order_type;
    }

    public void setOrder_type(int order_type) {
        this.order_type = order_type;
    }

    public long getSchedule_delivery_time() {
        return schedule_delivery_time;
    }

    public void setSchedule_delivery_time(long schedule_delivery_time) {
        this.schedule_delivery_time = schedule_delivery_time;
    }

    public long getPromised_delivery_time() {
        return promised_delivery_time;
    }

    public void setPromised_delivery_time(long promised_delivery_time) {
        this.promised_delivery_time = promised_delivery_time;
    }

    public boolean isIs_invoiced() {
        return is_invoiced;
    }

    public void setIs_invoiced(boolean is_invoiced) {
        this.is_invoiced = is_invoiced;
    }

    public String getInvoice_title() {
        return invoice_title;
    }

    public void setInvoice_title(String invoice_title) {
        this.invoice_title = invoice_title;
    }

    public double getFreight() {
        return freight;
    }

    public void setFreight(double freight) {
        this.freight = freight;
    }

    public int getAssign_type() {
        return assign_type;
    }

    public void setAssign_type(int assign_type) {
        this.assign_type = assign_type;
    }

    public int getPre_carrier_id() {
        return pre_carrier_id;
    }

    public void setPre_carrier_id(int pre_carrier_id) {
        this.pre_carrier_id = pre_carrier_id;
    }

    public String getPre_carrier_attr() {
        return pre_carrier_attr;
    }

    public void setPre_carrier_attr(String pre_carrier_attr) {
        this.pre_carrier_attr = pre_carrier_attr;
    }

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	@Override
	public String toString() {
		return "TShippingOption [order_type=" + order_type + ", schedule_delivery_time=" + schedule_delivery_time
				+ ", promised_delivery_time=" + promised_delivery_time + ", is_invoiced=" + is_invoiced
				+ ", invoice_title=" + invoice_title + ", freight=" + freight + ", assign_type=" + assign_type
				+ ", pre_carrier_id=" + pre_carrier_id + ", pre_carrier_attr=" + pre_carrier_attr + ", product_id="
				+ product_id + "]";
	}

}
