package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TMerchant {
    private @Index(1) String merchant_id;
    private @Index(2) String merchant_seq;
    private @Index(3) double total_price;
    private @Index(4) TContact contact;
    private @Index(5) TAddress address;
    private @Index(6) TLocation location;
    private @Index(7) String remark;
    private @Index(8) String extra_merchant_id;

    public String getMerchant_id() {
        return merchant_id;
    }

    public void setMerchant_id(String merchant_id) {
        this.merchant_id = merchant_id;
    }

    public String getMerchant_seq() {
        return merchant_seq;
    }

    public void setMerchant_seq(String merchant_seq) {
        this.merchant_seq = merchant_seq;
    }

    public double getTotal_price() {
        return total_price;
    }

    public void setTotal_price(double total_price) {
        this.total_price = total_price;
    }

    public TContact getContact() {
        return contact;
    }

    public void setContact(TContact contact) {
        this.contact = contact;
    }

    public TAddress getAddress() {
        return address;
    }

    public void setAddress(TAddress address) {
        this.address = address;
    }

    public TLocation getLocation() {
        return location;
    }

    public void setLocation(TLocation location) {
        this.location = location;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getExtra_merchant_id() {
        return extra_merchant_id;
    }

    public void setExtra_merchant_id(String extra_merchant_id) {
        this.extra_merchant_id = extra_merchant_id;
    }

	@Override
	public String toString() {
		return "TMerchant [merchant_id=" + merchant_id + ", merchant_seq=" + merchant_seq + ", total_price="
				+ total_price + ", contact=" + contact + ", address=" + address + ", location=" + location
				+ ", remark=" + remark + ", extra_merchant_id=" + extra_merchant_id + "]";
	}

}
