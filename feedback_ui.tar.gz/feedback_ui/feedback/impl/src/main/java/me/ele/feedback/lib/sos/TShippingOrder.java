package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TShippingOrder {
    private @Index(1) long tracking_id;
    private @Index(2) TPlatform platform_info;
    private @Index(3) TMerchant merchant_info;
    private @Index(4) TCarrier carrier_info;
    private @Index(5) TCarrierDriver driver_info;
    private @Index(6) TCustomer consumer_info;
    private @Index(7) TShippingOption shipping_option;
    private @Index(8) int shipping_state;
    private @Index(9) int shipping_reason_code;
    private @Index(10) double freight;
    private @Index(11) double discount;
    private @Index(12) int is_billed;
    private @Index(13) TBill bill;

    public long getTracking_id() {
        return tracking_id;
    }

    public void setTracking_id(long tracking_id) {
        this.tracking_id = tracking_id;
    }

    public TPlatform getPlatform_info() {
        return platform_info;
    }

    public void setPlatform_info(TPlatform platform_info) {
        this.platform_info = platform_info;
    }

    public TMerchant getMerchant_info() {
        return merchant_info;
    }

    public void setMerchant_info(TMerchant merchant_info) {
        this.merchant_info = merchant_info;
    }

    public TCarrier getCarrier_info() {
        return carrier_info;
    }

    public void setCarrier_info(TCarrier carrier_info) {
        this.carrier_info = carrier_info;
    }

    public TCarrierDriver getDriver_info() {
        return driver_info;
    }

    public void setDriver_info(TCarrierDriver driver_info) {
        this.driver_info = driver_info;
    }

    public TCustomer getConsumer_info() {
        return consumer_info;
    }

    public void setConsumer_info(TCustomer consumer_info) {
        this.consumer_info = consumer_info;
    }

    public TShippingOption getShipping_option() {
        return shipping_option;
    }

    public void setShipping_option(TShippingOption shipping_option) {
        this.shipping_option = shipping_option;
    }

    public int getShipping_state() {
        return shipping_state;
    }

    public void setShipping_state(int shipping_state) {
        this.shipping_state = shipping_state;
    }

    public int getShipping_reason_code() {
        return shipping_reason_code;
    }

    public void setShipping_reason_code(int shipping_reason_code) {
        this.shipping_reason_code = shipping_reason_code;
    }

    public double getFreight() {
        return freight;
    }

    public void setFreight(double freight) {
        this.freight = freight;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public int getIs_billed() {
        return is_billed;
    }

    public void setIs_billed(int is_billed) {
        this.is_billed = is_billed;
    }

	public TBill getBill() {
		return bill;
	}

	public void setBill(TBill bill) {
		this.bill = bill;
	}

}
