package me.ele.feedback.lib.sos;
public enum ShippingOrderStatus implements org.apache.thrift.TEnum {
  DELIVERY_STATUS_DEFAULT(0),
  DELIVERY_STATUS_SCHEDULE(1),
  DELIVERY_STATUS_CONFIRMING(10),
  DELIVERY_STATUS_CONFIRMED(20),
  DELIVERY_STATUS_DELIVERING(30),
  DELIVERY_STATUS_SUCCESSED(40),
  DELIVERY_STATUS_FAILED(50),
  DELIVERY_STATUS_FAILED_MERCHANT(51),
  DELIVERY_STATUS_FAILED_CARRIER(52),
  DELIVERY_STATUS_FAILED_USER(53),
  DELIVERY_STATUS_CANCELLED(60),
  DELIVERY_STATUS_CANCELLED_MERCHANT(61),
  DELIVERY_STATUS_CANCELLED_CARRIER(62),
  DELIVERY_STATUS_CANCELLED_USER(63),
  DELIVERY_STATUS_EXCEPTION(70);

  private final int value;

  private ShippingOrderStatus(int value) {
    this.value = value;
  }

  public int getValue() {
    return value;
  }
  
  public static ShippingOrderStatus findByValue(int value) { 
    switch (value) {
      case 0:
        return DELIVERY_STATUS_DEFAULT;
      case 1:
        return DELIVERY_STATUS_SCHEDULE;
      case 10:
        return DELIVERY_STATUS_CONFIRMING;
      case 20:
        return DELIVERY_STATUS_CONFIRMED;
      case 30:
        return DELIVERY_STATUS_DELIVERING;
      case 40:
        return DELIVERY_STATUS_SUCCESSED;
      case 50:
        return DELIVERY_STATUS_FAILED;
      case 51:
        return DELIVERY_STATUS_FAILED_MERCHANT;
      case 52:
        return DELIVERY_STATUS_FAILED_CARRIER;
      case 53:
        return DELIVERY_STATUS_FAILED_USER;
      case 60:
        return DELIVERY_STATUS_CANCELLED;
      case 61:
        return DELIVERY_STATUS_CANCELLED_MERCHANT;
      case 62:
        return DELIVERY_STATUS_CANCELLED_CARRIER;
      case 63:
        return DELIVERY_STATUS_CANCELLED_USER;
      case 70:
        return DELIVERY_STATUS_EXCEPTION;
      default:
        return null;
    }
  }
}
