package me.ele.feedback.lib.sos;
import me.ele.contract.exception.thrift.TUnknownException;

@SuppressWarnings("serial")
public class AuroraUnknownException extends TUnknownException {
    public AuroraUnknownException(String code, String message) {
        super(code, message);
    }
}
