package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TCustomer {
    private @Index(1) TContact contact;
    private @Index(2) double total_amount;
    /**
     * @see {@link PayMethod}
     */
    private @Index(3) int payment_method;
    private @Index(4) TAddress address;
    private @Index(5) TLocation location;
    private @Index(6) String remark;

    public TContact getContact() {
        return contact;
    }

    public void setContact(TContact contact) {
        this.contact = contact;
    }

    public double getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(double total_amount) {
        this.total_amount = total_amount;
    }

    public int getPayment_method() {
        return payment_method;
    }

    public void setPayment_method(int payment_method) {
        this.payment_method = payment_method;
    }

    public TAddress getAddress() {
        return address;
    }

    public void setAddress(TAddress address) {
        this.address = address;
    }

    public TLocation getLocation() {
        return location;
    }

    public void setLocation(TLocation location) {
        this.location = location;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

	@Override
	public String toString() {
		return "TCustomer [contact=" + contact + ", total_amount=" + total_amount + ", payment_method="
				+ payment_method + ", address=" + address + ", location=" + location + ", remark=" + remark + "]";
	}

}
