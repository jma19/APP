package me.ele.feedback.dao;

import java.util.List;

import me.ele.feedback.bean.SuggestionTicket;
import org.apache.ibatis.annotations.Param;

import me.ele.feedback.api.bean.FeedbackEntity;
import me.ele.feedback.api.dto.UpdateFeedbackDto;
import me.ele.feedback.bean.FeedbackTicket;

public interface FeedbackServiceDao {
    void updateFeedback(UpdateFeedbackDto updateFeedbackDto);

    int addFeedback(List<FeedbackEntity> feedbackEntities);

    List<FeedbackEntity> getFeedbackByDate(String start_time, String end_time);

    Integer getFeedbackCount(long waybill_num);

    List<Long> getWaybillNumByDateTypeProduct(@Param("stime") String stime, @Param("etime") String etime, @Param("productId") int productId, @Param("types") List<Integer> types, @Param("offset") int offset, @Param("limit") int limit);
   
    List<Long> getWaybillNumByDateProduct(@Param("stime") String stime, @Param("etime") String etime, @Param("productId") int productId, @Param("offset") int offset, @Param("limit") int limit);

    int getCountByDateProduct(@Param("stime") String stime, @Param("etime") String etime, @Param("productId") int productId);
    
    int getCountByDateTypeProduct(@Param("stime") String stime, @Param("etime") String etime, @Param("productId") int productId, @Param("types") List<Integer> types);

    void createFeedbackTickets(List<FeedbackTicket> feedbackTickets);

    void createSuggestionTicket(SuggestionTicket suggstionTicket);
}
