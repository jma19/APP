package me.ele.feedback.lib.kf5.support.model;

import java.util.List;


/**
 * ����(�ͷ�)model
 * @author chosen
 *
 * @version ����ʱ�䣺2015��9��1��  ����2:07:04
 */
public class Ticket {

	private int id; //��������ʱϵͳ�Զ�����
	 
	private String url; // �˹�����url��ַ
	
	private String title; // ����
	
	private String description; // ��������������һ�������ظ����ı�����
	
	private String type; // ���ͣ�"problem", "incident", "question", "task"
	
	private String status; // ״̬��"new","open", "pending", "solved", "closed"
	
	private String priority; // ���ȼ���"low", "medium", "high", "urgent"
	
	private String recipient; // �ʼ�������ԭ�ռ��˵�ַ
	
	private int requesterId; // ������id
	
	private int organizationId; // ������������˾��֯id
	
	private int assigneeId;// ����ͷ�id
	
	private int groupId; // ����ͷ���id
	
	private int problemId; // incident������������problem������id
	
	private long dueDate; // task�����Ľ�ֹʱ��
	
	private String createdAt; // ����ʱ��
	
	private String updatedAt; // ������ʱ��
	
	private String assigneedAt;//�״α�����ʱ��
	
	private String resolvedAt; //���������ʱ��
	
	private String closedAt;//�������ر�ʱ��
	
	private String source; //������Դ��"web", "tab", "chat", "email","mobile", "weibo", "api"
	
	private String satisfactionRating; // ���������
	
	private List<CustomField> listCustomFields; //�����Զ����ֶ�

	public int getId() {
		return id;
	}

	public Ticket setId(int id) {
		this.id = id;
		return this;
	}

	public String getUrl() {
		return url;
	}

	public Ticket setUrl(String url) {
		this.url = url;
		return this;
	}

	public String getTitle() {
		return title;
	}

	public Ticket setTitle(String title) {
		this.title = title;
		return this;
	}

	public String getDescription() {
		return description;
	}

	public Ticket setDescription(String description) {
		this.description = description;
		return this;
	}

	public String getType() {
		return type;
	}

	public Ticket setType(String type) {
		this.type = type;
		return this;
	}

	public String getStatus() {
		return status;
	}

	public Ticket setStatus(String status) {
		this.status = status;
		return this;
	}

	public String getPriority() {
		return priority;
	}

	public Ticket setPriority(String priority) {
		this.priority = priority;
		return this;
	}

	public String getRecipient() {
		return recipient;
	}

	public Ticket setRecipient(String recipient) {
		this.recipient = recipient;
		return this;
	}

	public int getRequesterId() {
		return requesterId;
	}

	public Ticket setRequesterId(int requesterId) {
		this.requesterId = requesterId;
		return this;
	}

	public int getOrganizationId() {
		return organizationId;
	}

	public Ticket setOrganizationId(int organizationId) {
		this.organizationId = organizationId;
		return this;
	}

	public int getAssigneeId() {
		return assigneeId;
	}

	public Ticket setAssigneeId(int assigneeId) {
		this.assigneeId = assigneeId;
		return this;
	}

	public int getGroupId() {
		return groupId;
	}

	public Ticket setGroupId(int groupId) {
		this.groupId = groupId;
		return this;
	}

	public int getProblemId() {
		return problemId;
	}

	public Ticket setProblemId(int problemId) {
		this.problemId = problemId;
		return this;
	}

	
	public long getDueDate() {
		return dueDate;
	}

	public Ticket setDueDate(long dueDate) {
		this.dueDate = dueDate;
		return this;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public Ticket setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
		return this;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public Ticket setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

	public String getAssigneedAt() {
		return assigneedAt;
	}

	public Ticket setAssigneedAt(String assigneedAt) {
		this.assigneedAt = assigneedAt;
		return this;
	}

	public String getResolvedAt() {
		return resolvedAt;
	}

	public Ticket setResolvedAt(String resolvedAt) {
		this.resolvedAt = resolvedAt;
		return this;
	}

	public String getClosedAt() {
		return closedAt;
	}

	public Ticket setClosedAt(String closedAt) {
		this.closedAt = closedAt;
		return this;
	}

	public String getSource() {
		return source;
	}

	public Ticket setSource(String source) {
		this.source = source;
		return this;
	}

	public String getSatisfactionRating() {
		return satisfactionRating;
	}

	public Ticket setSatisfactionRating(String satisfactionRating) {
		this.satisfactionRating = satisfactionRating;
		return this;
	}

	public List<CustomField> getListCustomFields() {
		return listCustomFields;
	}

	public Ticket setListCustomFields(List<CustomField> listCustomFields) {
		this.listCustomFields = listCustomFields;
		return this;
	}

	@Override
	public String toString() {
		return "Ticket{" +
				"id=" + id +
				", url='" + url + '\'' +
				", title='" + title + '\'' +
				", description='" + description + '\'' +
				", type='" + type + '\'' +
				", status='" + status + '\'' +
				", priority='" + priority + '\'' +
				", recipient='" + recipient + '\'' +
				", requesterId=" + requesterId +
				", organizationId=" + organizationId +
				", assigneeId=" + assigneeId +
				", groupId=" + groupId +
				", problemId=" + problemId +
				", dueDate=" + dueDate +
				", createdAt='" + createdAt + '\'' +
				", updatedAt='" + updatedAt + '\'' +
				", assigneedAt='" + assigneedAt + '\'' +
				", resolvedAt='" + resolvedAt + '\'' +
				", closedAt='" + closedAt + '\'' +
				", source='" + source + '\'' +
				", satisfactionRating='" + satisfactionRating + '\'' +
				", listCustomFields=" + listCustomFields +
				'}';
	}
}
