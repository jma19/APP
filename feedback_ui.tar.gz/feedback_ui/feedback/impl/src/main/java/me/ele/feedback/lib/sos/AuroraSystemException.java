package me.ele.feedback.lib.sos;
import me.ele.contract.exception.thrift.TSystemException;

@SuppressWarnings("serial")
public class AuroraSystemException extends TSystemException {
    public AuroraSystemException(String code, String message) {
        super(code, message);
    }
}
