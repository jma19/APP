package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TCarrierDetail {
    private @Index(1) int carrier_id;
    private @Index(2) String carrier_code;
    private @Index(3) String carrier_name;
    private @Index(4) String carrier_address;
    private @Index(5) String carrier_contact_name;
    private @Index(6) String carrier_primary_phone;
    private @Index(7) String carrier_second_phone;

    public int getCarrier_id() {
        return carrier_id;
    }

    public void setCarrier_id(int carrier_id) {
        this.carrier_id = carrier_id;
    }

    public String getCarrier_code() {
        return carrier_code;
    }

    public void setCarrier_code(String carrier_code) {
        this.carrier_code = carrier_code;
    }

    public String getCarrier_name() {
        return carrier_name;
    }

    public void setCarrier_name(String carrier_name) {
        this.carrier_name = carrier_name;
    }

    public String getCarrier_address() {
        return carrier_address;
    }

    public void setCarrier_address(String carrier_address) {
        this.carrier_address = carrier_address;
    }

    public String getCarrier_contact_name() {
        return carrier_contact_name;
    }

    public void setCarrier_contact_name(String carrier_contact_name) {
        this.carrier_contact_name = carrier_contact_name;
    }

    public String getCarrier_primary_phone() {
        return carrier_primary_phone;
    }

    public void setCarrier_primary_phone(String carrier_primary_phone) {
        this.carrier_primary_phone = carrier_primary_phone;
    }

    public String getCarrier_second_phone() {
        return carrier_second_phone;
    }

    public void setCarrier_second_phone(String carrier_second_phone) {
        this.carrier_second_phone = carrier_second_phone;
    }
}
