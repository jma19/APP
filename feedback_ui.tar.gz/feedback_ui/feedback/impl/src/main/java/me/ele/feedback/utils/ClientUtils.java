package me.ele.feedback.utils;

import me.ele.contract.client.ClientUtil;

public class ClientUtils {

    public static <T> T getClient(Class<T> clazz) {
        return ClientUtil.getContext().getClient(clazz);
    }
}
