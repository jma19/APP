package me.ele.feedback.Service;

import me.ele.contract.exception.ServiceException;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.feedback.utils.ClientUtils;
import me.ele.feedback.lib.sos.AuroraService;
import me.ele.feedback.lib.sos.AuroraSystemException;
import me.ele.feedback.lib.sos.AuroraUserException;
import me.ele.feedback.lib.sos.TShippingOrder;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

import static me.ele.feedback.constant.ExceptionConstants.SYSTEM_EXCEPTION;
import static me.ele.feedback.constant.ExceptionConstants.UNKNOWN_EXCEPTION;

/**
 * Created by majun on 16/1/19.
 */
@Service
public class ShippingOrderService {

    private static final Log logger = LogFactory.getLog(ShippingOrderService.class);

    private AuroraService auroraService;

    @PostConstruct
    public void initService() {
        this.auroraService = ClientUtils.getClient(AuroraService.class);
    }

    public TShippingOrder getShippingOrder(Long trackingId) throws ServiceException {
        try {
            logger.info("invoke sos getShippingOrder, trackingId ={} ", trackingId);
            return auroraService.get_shipping_order(trackingId);
        } catch (AuroraUserException exp) {
            logger.error("调用sos发生AuroraUserException异常, message={}", exp.getMessage());
            //包含shippingOrder not found error
            throw new ServiceException(exp.getCode(), exp.getMessage());
        } catch (AuroraSystemException exp) {
            logger.error("调用sos发生AuroraSystemException异常, message={}", exp.getMessage());
            throw SYSTEM_EXCEPTION;
        } catch (Exception exp) {
            logger.error("调用sos未知异常, e=", exp);
            throw UNKNOWN_EXCEPTION;
        }

    }

}
