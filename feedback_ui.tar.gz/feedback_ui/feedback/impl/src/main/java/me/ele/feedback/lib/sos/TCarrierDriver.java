package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TCarrierDriver {
    private @Index(1) String driver_name;
    private @Index(2) String driver_phone;

    public String getDriver_name() {
        return driver_name;
    }

    public void setDriver_name(String driver_name) {
        this.driver_name = driver_name;
    }

    public String getDriver_phone() {
        return driver_phone;
    }

    public void setDriver_phone(String driver_phone) {
        this.driver_phone = driver_phone;
    }
}
