package me.ele.feedback.dao;

import me.ele.feedback.bean.EvaluationTicket;

import java.util.List;

/**
 * Created by majun on 16/2/25.
 */
public interface EvaluationServiceDao {

    void createEvaluationTickets(List<EvaluationTicket> evaluationTicketList);
}
