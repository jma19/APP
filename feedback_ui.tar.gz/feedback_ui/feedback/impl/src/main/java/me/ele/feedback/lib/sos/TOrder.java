package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TOrder {
    private @Index(1) TPlatform platform_info;
    private @Index(2) TMerchant merchant_info;
    private @Index(3) TCustomer consumer_info;
    private @Index(4) TShippingOption option;
    private @Index(5) String item_detail_json;
    private @Index(6) TBill bill;

    public TPlatform getPlatform_info() {
        return platform_info;
    }

    public void setPlatform_info(TPlatform platform_info) {
        this.platform_info = platform_info;
    }

    public TMerchant getMerchant_info() {
        return merchant_info;
    }

    public void setMerchant_info(TMerchant merchant_info) {
        this.merchant_info = merchant_info;
    }

    public TCustomer getConsumer_info() {
        return consumer_info;
    }

    public void setConsumer_info(TCustomer consumer_info) {
        this.consumer_info = consumer_info;
    }

    public TShippingOption getOption() {
        return option;
    }

    public void setOption(TShippingOption option) {
        this.option = option;
    }

    public String getItem_detail_json() {
        return item_detail_json;
    }

    public void setItem_detail_json(String item_detail_json) {
        this.item_detail_json = item_detail_json;
    }

	public TBill getBill() {
		return bill;
	}

	public void setBill(TBill bill) {
		this.bill = bill;
	}

	@Override
	public String toString() {
		return "TOrder [platform_info=" + platform_info + ", merchant_info=" + merchant_info + ", consumer_info="
				+ consumer_info + ", option=" + option + ", item_detail_json=" + item_detail_json + ", bill=" + bill
				+ "]";
	}
    
}
