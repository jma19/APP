package me.ele.feedback.Service;

import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * Created by majun on 16/1/25.
 */
@Service
public class AsyMsgSender {

    private final static Log logger = LogFactory.getLog(AsyMsgSender.class);

    @Resource(name = "feedbackTemplate")
    private AmqpTemplate amqpTemplate;

    public void sendAsyMessage(String routingKey, Object object) {
        logger.info("发送异步【{}】MQ消息:{}", routingKey, object);
        amqpTemplate.convertAndSend(routingKey, object);
    }
}
