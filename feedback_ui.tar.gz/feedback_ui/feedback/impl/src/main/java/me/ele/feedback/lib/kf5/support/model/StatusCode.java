package me.ele.feedback.lib.kf5.support.model;

public class StatusCode {

	public static final int OK = 0;
	
}
