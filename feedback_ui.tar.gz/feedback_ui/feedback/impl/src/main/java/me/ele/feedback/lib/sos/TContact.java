package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TContact {
    private @Index(1) String name;
    private @Index(2) String primary_phone;
    private @Index(3) String second_phone;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrimary_phone() {
        return primary_phone;
    }

    public void setPrimary_phone(String primary_phone) {
        this.primary_phone = primary_phone;
    }

    public String getSecond_phone() {
        return second_phone;
    }

    public void setSecond_phone(String second_phone) {
        this.second_phone = second_phone;
    }
}
