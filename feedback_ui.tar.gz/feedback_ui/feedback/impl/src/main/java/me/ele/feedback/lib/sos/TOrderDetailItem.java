package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TOrderDetailItem {
    private @Index(1) int category_id;
    private @Index(2) String name;
    private @Index(3) double price;
    private @Index(4) int quantity;

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
