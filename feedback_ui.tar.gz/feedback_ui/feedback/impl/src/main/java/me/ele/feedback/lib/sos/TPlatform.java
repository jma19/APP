package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TPlatform {
    private @Index(1) int id;
    private @Index(2) String tracking_id;
    private @Index(3) String name;
    private @Index(4) long order_created_time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTracking_id() {
        return tracking_id;
    }

    public void setTracking_id(String tracking_id) {
        this.tracking_id = tracking_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getOrder_created_time() {
        return order_created_time;
    }

    public void setOrder_created_time(long order_created_time) {
        this.order_created_time = order_created_time;
    }

	@Override
	public String toString() {
		return "TPlatform [id=" + id + ", tracking_id=" + tracking_id + ", name=" + name + ", order_created_time="
				+ order_created_time + "]";
	}

}
