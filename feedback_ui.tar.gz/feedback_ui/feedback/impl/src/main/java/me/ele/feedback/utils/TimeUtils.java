package me.ele.feedback.utils;

import me.ele.contract.exception.ServiceException;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import org.apache.commons.lang.time.FastDateFormat;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;

import static me.ele.feedback.constant.ExceptionConstants.ILLEGAL_PARAMETER_EXCEPTION;

/**
 * Created by majun on 16/1/19.
 */
public class TimeUtils {
    private static final String TIME_FORMAT = "\\d{4}-{1}\\d{2}-{1}\\d{2}";
    private static final Log logger = LogFactory.getLog(TimeUtils.class);

    private static final FastDateFormat fastDateFormat = FastDateFormat.getInstance("yyyy-MM-dd");

    public static String increaseOneDay(String time) throws ServiceException {
        Calendar cal = Calendar.getInstance();
        try {
            Date parse = new SimpleDateFormat("yyyy-MM-dd").parse(time);
            cal.setTime(parse);
        } catch (Exception e) {
            logger.error("时间解析出错, time={},error={}", time, e);
            throw ILLEGAL_PARAMETER_EXCEPTION;
        }
        cal.add(Calendar.DATE, 1);
        return fastDateFormat.format(cal.getTime());
    }

    public static String getYesDay() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        return fastDateFormat.format(cal);
    }

    public static String getYesDayInitialTime() {
        return getYesDay().concat(" 00:00:00");
    }

    public static String getYesDayEndTime() {
        return getYesDay().concat(" 23:59:59");
    }


    public static boolean islegalFormatTime(String time) {
        return Pattern.compile(TIME_FORMAT).matcher(time).find();
    }

    public static String getYMDOfDate(String time){
        long longTime = 0;
        try {
            longTime = new SimpleDateFormat("yyyy-MM-dd").parse(time).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return getYMDOfDate(new Timestamp(longTime));
    }


    public static String getYMDOfDate(Timestamp timestamp){
        return fastDateFormat.format(timestamp.getTime());
    }

    public static String getHMSOfDate(Timestamp timestamp){
        return FastDateFormat.getInstance("HH:mm:ss").format(timestamp);
    }
}
