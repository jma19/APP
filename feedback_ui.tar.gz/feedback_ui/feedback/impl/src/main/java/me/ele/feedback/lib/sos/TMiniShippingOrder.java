package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TMiniShippingOrder {
    private @Index(1) TCarrier carrier_info;
    private @Index(2) TCarrierDriver driver_info;
    private @Index(3) TCustomer consumer_info;

    public TCarrier getCarrier_info() {
        return carrier_info;
    }

    public void setCarrier_info(TCarrier carrier_info) {
        this.carrier_info = carrier_info;
    }

    public TCarrierDriver getDriver_info() {
        return driver_info;
    }

    public void setDriver_info(TCarrierDriver driver_info) {
        this.driver_info = driver_info;
    }

    public TCustomer getConsumer_info() {
        return consumer_info;
    }

    public void setConsumer_info(TCustomer consumer_info) {
        this.consumer_info = consumer_info;
    }
}
