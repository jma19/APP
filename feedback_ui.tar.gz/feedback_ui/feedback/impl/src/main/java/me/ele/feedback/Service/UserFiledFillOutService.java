package me.ele.feedback.Service;

import com.google.common.collect.Lists;
import me.ele.feedback.api.dto.FeedbackTicketDto;
import me.ele.feedback.lib.kf5.support.model.CustomField;
import org.springframework.stereotype.Service;

import java.util.List;

import static me.ele.feedback.constant.PublicConstants.complainTypesMap;
import static me.ele.feedback.constant.PublicConstants.feedbackReasonsMap;
import static me.ele.feedback.utils.NotNullTransformer.getNotNullComponent;

/**
 * Created by majun on 16/2/23.
 */
@Service
public class UserFiledFillOutService {

    public List<CustomField> createCustomFilelds(FeedbackTicketDto feedbackTicket) {

        List<CustomField> customFields = Lists.newArrayList();

        Integer complainType = feedbackTicket.getComplainType();
        List<Integer> complainReasonIds = feedbackTicket.getComplainReasonIds();

        customFields.add(new CustomField().setName("field_6079").setValue("Undefined"));

        //添加投诉类型
        customFields.add(new CustomField().setName("field_6086").setValue(complainTypesMap.get(complainType)));
        //添加运单id
        customFields.add(new CustomField().setName("field_6585").setValue(String.valueOf(getNotNullComponent(feedbackTicket.getTrackingId()))));
        //添加订单id
        customFields.add(new CustomField().setName("field_6584").setValue(getNotNullComponent(feedbackTicket.getOrderId())));

        //骑手投诉商户
        if (complainType == 1) {
            //骑手姓名
            customFields.add(new CustomField().setName("field_6589").setValue(getNotNullComponent(feedbackTicket.getComplainSource().getName())));
            //骑手电话
            customFields.add(new CustomField().setName("field_6590").setValue(getNotNullComponent(feedbackTicket.getComplainSource().getPhone())));
            //商家姓名
            customFields.add(new CustomField().setName("field_6586").setValue(getNotNullComponent(feedbackTicket.getComplainTarget().getName())));
            //商家电话
            customFields.add(new CustomField().setName("field_6588").setValue(getNotNullComponent(feedbackTicket.getComplainTarget().getPhone())));

            //用户骑手标签
            if (complainReasonIds != null && !complainReasonIds.isEmpty()) {
                customFields.add(new CustomField().setName("field_6278").setValue(feedbackReasonsMap.get(complainReasonIds.get(0))));
            }
            else{
                System.out.println("标签设置");
                customFields.add(new CustomField().setName("field_6278").setValue("Undefined"));
            }
        }

        //商户投诉骑手
        else if (complainType == 2) {
            //商家姓名
            customFields.add(new CustomField().setName("field_6586").setValue(getNotNullComponent(feedbackTicket.getComplainSource().getName())));
            //商家电话
            customFields.add(new CustomField().setName("field_6588").setValue(getNotNullComponent(feedbackTicket.getComplainSource().getPhone())));

            //骑手姓名
            customFields.add(new CustomField().setName("field_6589").setValue(getNotNullComponent(feedbackTicket.getComplainTarget().getName())));
            //骑手电话
            customFields.add(new CustomField().setName("field_6590").setValue(getNotNullComponent(feedbackTicket.getComplainTarget().getPhone())));

            //商家电话
            customFields.add(new CustomField().setName("field_6092").setValue(getNotNullComponent(feedbackTicket.getComplainSource().getPhone())));

            //用户骑手标签
            if (complainReasonIds != null && !complainReasonIds.isEmpty()) {
                customFields.add(new CustomField().setName("field_6578").setValue(feedbackReasonsMap.get(complainReasonIds.get(0))));
            }
            else{
                customFields.add(new CustomField().setName("field_6578").setValue("Undefined"));
            }

        }
        //用户投诉骑手
        else if (complainType == 3) {
            //用户姓名
            customFields.add(new CustomField().setName("field_6104").setValue(feedbackTicket.getComplainSource().getName()));
            //用户电话
            customFields.add(new CustomField().setName("field_6105").setValue(feedbackTicket.getComplainSource().getPhone()));
            //骑手姓名
            customFields.add(new CustomField().setName("field_6589").setValue(feedbackTicket.getComplainTarget().getName()));
            //骑手电话
            customFields.add(new CustomField().setName("field_6590").setValue(feedbackTicket.getComplainTarget().getPhone()));

            //标签
            if (complainReasonIds != null && !complainReasonIds.isEmpty()) {
                customFields.add(new CustomField().setName("field_6580").setValue(feedbackReasonsMap.get(complainReasonIds.get(0))));
            }
            else{
                customFields.add(new CustomField().setName("field_6580").setValue("Undefined"));

            }

        }
        //骑手申诉
        else if (complainType == 4) {
            //骑手姓名
            customFields.add(new CustomField().setName("field_6589").setValue(getNotNullComponent(feedbackTicket.getComplainSource().getName())));
            //骑手电话
            customFields.add(new CustomField().setName("field_6590").setValue(getNotNullComponent(feedbackTicket.getComplainSource().getPhone())));

            //标签
            if (complainReasonIds != null && !complainReasonIds.isEmpty()) {
                customFields.add(new CustomField().setName("field_6143").setValue(feedbackReasonsMap.get(complainReasonIds.get(0))));
            }
            else{
                customFields.add(new CustomField().setName("field_6143").setValue("Undefined"));

            }

        }

        //商户申诉
        else if (complainType == 5) {
            //商家姓名
            customFields.add(new CustomField().setName("field_6586").setValue(getNotNullComponent(feedbackTicket.getComplainSource().getName())));
            //商家电话
            customFields.add(new CustomField().setName("field_6588").setValue(getNotNullComponent(feedbackTicket.getComplainSource().getPhone())));
            customFields.add(new CustomField().setName("field_6119").setValue(getNotNullComponent(feedbackTicket.getComplainSource().getPhone())));
        }
        //投诉平台
        else if (complainType == 6) {
            //no fields 应该是有投诉人
        }

        return customFields;
    }

}
