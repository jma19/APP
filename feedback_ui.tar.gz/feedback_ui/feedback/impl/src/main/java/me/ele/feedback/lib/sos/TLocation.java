package me.ele.feedback.lib.sos;
import me.ele.contract.annotation.Index;

public class TLocation {
    private @Index(1) String longitude;
    private @Index(2) String latitude;
    private @Index(3) String location_text;

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLocation_text() {
        return location_text;
    }

    public void setLocation_text(String location_text) {
        this.location_text = location_text;
    }
}
