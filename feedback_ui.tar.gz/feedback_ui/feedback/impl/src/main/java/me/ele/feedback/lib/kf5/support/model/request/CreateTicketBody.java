package me.ele.feedback.lib.kf5.support.model.request;

import me.ele.feedback.lib.kf5.support.model.Comment;
import me.ele.feedback.lib.kf5.support.model.CustomField;

import java.util.Date;
import java.util.List;

/**
 * Created by majun on 16/1/19.
 */
public class CreateTicketBody {
    
    private String title;
    private Comment comment;
    private Integer requester_id;
    private Requester requester;
    private Integer assignee_id;
    private Integer group_id;
    private String type;
    private String status;
    private String priority;
    private Integer problem_id;
    private Date due_at;
    private List tags;
    private List collaborator_ids;
    private List<CustomField> custom_fields;

    public Comment getComment() {
        return comment;
    }

    public CreateTicketBody setComment(Comment comment) {
        this.comment = comment;
        return this;
    }

    public CreateTicketBody setRequester(Requester requester) {
        this.requester = requester;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public CreateTicketBody setTitle(String title) {
        this.title = title;
        return this;
    }

    public Integer getRequester_id() {
        return requester_id;
    }

    public CreateTicketBody setRequester_id(Integer requester_id) {
        this.requester_id = requester_id;
        return this;
    }

    public Object getRequester() {
        return requester;
    }


    public Integer getAssignee_id() {
        return assignee_id;
    }

    public CreateTicketBody setAssignee_id(Integer assignee_id) {
        this.assignee_id = assignee_id;
        return this;
    }

    public Integer getGroup_id() {
        return group_id;
    }

    public CreateTicketBody setGroup_id(Integer group_id) {
        this.group_id = group_id;
        return this;
    }

    public String getType() {
        return type;
    }

    public CreateTicketBody setType(String type) {
        this.type = type;
        return this;
    }

    public String getStatus() {
        return status;
    }

    public CreateTicketBody setStatus(String status) {
        this.status = status;
        return this;
    }

    public String getPriority() {
        return priority;
    }

    public CreateTicketBody setPriority(String priority) {
        this.priority = priority;
        return this;
    }

    public Integer getProblem_id() {
        return problem_id;
    }

    public CreateTicketBody setProblem_id(Integer problem_id) {
        this.problem_id = problem_id;
        return this;
    }

    public Date getDue_at() {
        return due_at;
    }

    public CreateTicketBody setDue_at(Date due_at) {
        this.due_at = due_at;
        return this;
    }

    public List getTags() {
        return tags;
    }

    public CreateTicketBody setTags(List tags) {
        this.tags = tags;
        return this;
    }

    public List getCollaborator_ids() {
        return collaborator_ids;
    }

    public CreateTicketBody setCollaborator_ids(List collaborator_ids) {
        this.collaborator_ids = collaborator_ids;
        return this;
    }

    public List getCustom_fields() {
        return custom_fields;
    }

    public CreateTicketBody setCustom_fields(List custom_fields) {
        this.custom_fields = custom_fields;
        return this;
    }

    @Override
    public String toString() {
        return "CreateTicketBody{" +
                "assignee_id=" + assignee_id +
                ", title='" + title + '\'' +
                ", comment=" + comment +
                ", requester_id=" + requester_id +
                ", requester=" + requester +
                ", group_id=" + group_id +
                ", type='" + type + '\'' +
                ", status='" + status + '\'' +
                ", priority='" + priority + '\'' +
                ", problem_id=" + problem_id +
                ", due_at=" + due_at +
                ", tags=" + tags +
                ", collaborator_ids=" + collaborator_ids +
                ", custom_fields=" + custom_fields +
                '}';
    }
}
