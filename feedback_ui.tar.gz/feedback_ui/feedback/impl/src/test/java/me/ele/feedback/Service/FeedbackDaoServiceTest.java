package me.ele.feedback.Service;

import me.ele.feedback.api.FeedbackService;
import me.ele.feedback.api.bean.ComplainObject;
import me.ele.feedback.api.dto.FeedbackTicketDto;
import me.ele.feedback.bean.SuggestionTicket;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.Timestamp;

import static org.junit.Assert.*;

/**
 * Created by majun on 16/3/3.
 */
public class FeedbackDaoServiceTest {
    @Test
    public void testName() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        FeedbackDaoService feedbackDaoService = (FeedbackDaoService) context.getBean("feedbackDaoService");

        FeedbackTicketDto feedbackInsertDto = new FeedbackTicketDto()
                .setSourceId(1)
                .setProductId(1)
                .setComplainType(6)
                .setComplainSource(new ComplainObject().setId(1l).setName("majun").setPhone("172738479391"))
                .setComplainAt(System.currentTimeMillis())
                .setSolvedAt(null)    //solvedAt 填0 有问题
                .setRemark("we should do ....");

        feedbackDaoService.createSuggestion(getSuggstionTicket(feedbackInsertDto));

    }
    private SuggestionTicket getSuggstionTicket(FeedbackTicketDto feedbackTicketDto){
        return new SuggestionTicket()
                .setProductId(feedbackTicketDto.getProductId())
                .setSourceId(feedbackTicketDto.getSourceId())
                .setRemark(feedbackTicketDto.getRemark())
                .setSugAt(getTimestamp(feedbackTicketDto.getComplainAt()))
                .setSugSourceId(getComplainId(feedbackTicketDto.getComplainSource()))
                .setSugSourceName(getComplainName(feedbackTicketDto.getComplainSource()))
                .setSugSourcePhone(getComplainPhone(feedbackTicketDto.getComplainSource()))
                .setSugTargetId(getComplainId(feedbackTicketDto.getComplainTarget()))
                .setSugTargetName(getComplainName(feedbackTicketDto.getComplainTarget()))
                .setSugTargetPhone(getComplainPhone(feedbackTicketDto.getComplainTarget()));

    }
    private String getComplainName(ComplainObject complainObject) {
        return complainObject == null ? "" : complainObject.getName();
    }

    private String getComplainPhone(ComplainObject complainObject) {
        return complainObject == null ? "" : complainObject.getPhone();
    }

    private Long getComplainId(ComplainObject complainObject) {
        return complainObject == null ? 0 : complainObject.getId();
    }


    private String getNotNullComponent(String comp) {
        return comp == null ? "" : comp;
    }

    private Long getNotNullComponent(Long comp) {
        return comp == null ? Long.valueOf(0) : comp;
    }

    private Integer getNotNullComponent(Integer comp) {
        return comp == null ? Integer.valueOf(0) : comp;
    }


    private Timestamp getTimestamp(Long time) {

        return time == null ? new Timestamp(System.currentTimeMillis()) : new Timestamp(time);
    }

}