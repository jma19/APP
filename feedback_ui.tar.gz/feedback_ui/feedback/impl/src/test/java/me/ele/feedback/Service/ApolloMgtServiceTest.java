package me.ele.feedback.Service;

import me.ele.managementService.model.DTO.OrderSourceCode;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by majun on 16/3/1.
 */
public class ApolloMgtServiceTest {
    @Test
    public void testName() throws Exception {
        //
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        ApolloMgtService apolloMgtService = (ApolloMgtService) context.getBean("apolloMgtService");
        apolloMgtService.getShippingOrderDetail(OrderSourceCode.ELEME.getValue(), "100025383266285804");
    }
}