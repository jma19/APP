package me.ele.feedback.Service;

import com.google.common.collect.Lists;
import me.ele.feedback.api.bean.ComplainObject;
import me.ele.feedback.api.dto.FeedbackTicketDto;
import me.ele.feedback.lib.kf5.support.model.Ticket;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Arrays;

/**
 * Created by majun on 16/2/24.
 */
public class Kf5ServiceTest {
    /*
    put(1, "骑手投诉商户");
     */
    @Test
    public void should_create_a_ticket_when_driver_complain_merchant() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        Kf5Service kf5Service = (Kf5Service) context.getBean("kf5Service");

        FeedbackTicketDto feedbackInsertDto = new FeedbackTicketDto()
                .setComplainType(1)
                .setOrderId("12344")
                .setTrackingId(123456789l)
                .setProductId(1)
                .setSourceId(1)
                .setComplainReasonIds(Arrays.asList(6, 7))
                .setComplainSource(new ComplainObject().setName("妖风").setPhone("18168058010"))
                .setComplainTarget(new ComplainObject().setName("妖风test").setPhone("16827389278"));
        Ticket ticket = kf5Service.createTicket(feedbackInsertDto);
    }

    //2.商户投诉骑手
    @Test
    public void should_create_a_ticket_when_merchant_complain_driver() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        Kf5Service kf5Service = (Kf5Service) context.getBean("kf5Service");

        FeedbackTicketDto feedbackInsertDto = new FeedbackTicketDto()
                .setComplainType(2)
                .setOrderId("12344")
                .setTrackingId(123456789l)
                .setProductId(1)
                .setSourceId(1)
//                .setComplainReasonIds(Arrays.asList(31, 32))
                .setComplainSource(new ComplainObject().setName("马军").setPhone("18168058010"))
                .setComplainTarget(new ComplainObject().setName("妖风t").setPhone("16827389278"));
        Ticket ticket = kf5Service.createTicket(feedbackInsertDto);
    }

    //2.用户投诉骑手
    @Test
    public void should_create_a_ticket_when_user_complain_driver() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        Kf5Service kf5Service = (Kf5Service) context.getBean("kf5Service");

        FeedbackTicketDto feedbackInsertDto = new FeedbackTicketDto()
                .setComplainType(3)
                .setOrderId("12344")
                .setTrackingId(123456789l)
                .setProductId(1)
                .setSourceId(1)
                .setComplainReasonIds(Arrays.asList(31, 32))
                .setComplainSource(new ComplainObject().setName("马军").setPhone("18168058010"))
                .setComplainTarget(new ComplainObject().setName("妖风").setPhone("16827389278"));
        Ticket ticket = kf5Service.createTicket(feedbackInsertDto);
    }


    @Test
    public void should_create_a_ticket_when_driver_complain() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        Kf5Service kf5Service = (Kf5Service) context.getBean("kf5Service");

        FeedbackTicketDto feedbackInsertDto = new FeedbackTicketDto()
                .setComplainType(4)
                .setOrderId("12344")
                .setTrackingId(123456789l)
                .setProductId(1)
                .setSourceId(1)
                .setComplainReasonIds(Arrays.asList(45, 46))
                .setComplainSource(new ComplainObject().setName("马军").setPhone("18168058010"));
        Ticket ticket = kf5Service.createTicket(feedbackInsertDto);
    }


    @Test
    public void should_create_a_ticket_when_merchant_complain() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        Kf5Service kf5Service = (Kf5Service) context.getBean("kf5Service");

        FeedbackTicketDto feedbackInsertDto = new FeedbackTicketDto()
                .setComplainType(5)
                .setOrderId("12344")
                .setTrackingId(123456789l)
                .setProductId(1)
                .setSourceId(1)
                .setComplainReasonIds(Arrays.asList(45, 46))
                .setComplainSource(new ComplainObject().setName("马军").setPhone("18168058010"));
        Ticket ticket = kf5Service.createTicket(feedbackInsertDto);
    }

    //投诉平台
    @Test
    public void should_create_a_ticket_when_complain_platform() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        Kf5Service kf5Service = (Kf5Service) context.getBean("kf5Service");

        FeedbackTicketDto feedbackInsertDto = new FeedbackTicketDto()
                .setComplainType(6)
                .setOrderId("12344")
                .setTrackingId(123456789l)
                .setProductId(1)
                .setSourceId(1)
//                .setComplainReasonIds(Arrays.asList(45, 46))
                .setComplainSource(new ComplainObject().setName("马军").setPhone("18168058010"));
        Ticket ticket = kf5Service.createTicket(feedbackInsertDto);
    }


    @Test
    public void should_create_a_ticket_when_driver_complain_merchant_() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        Kf5Service kf5Service = (Kf5Service) context.getBean("kf5Service");

        FeedbackTicketDto feedbackInsertDto = new FeedbackTicketDto()
                .setSourceId(1)
                .setProductId(1)
                .setComplainType(1)
                .setComplainSource(new ComplainObject().setId(1l).setName("majun").setPhone("172738479391"))
                .setComplainTarget(new ComplainObject().setId(2l).setName("test").setPhone("12473292419"))
                .setComplainReasonIds(Lists.newArrayList())
                .setOrderId("12874773403171522")
                .setTrackingId(91423956702853547l)
                .setComplainAt(System.currentTimeMillis())
                .setSolvedAt(null)    //solvedAt 填0 有问题
                .setRemark("hello, I think, there is a problem");


        Ticket ticket = kf5Service.createTicket(feedbackInsertDto);

    }



}