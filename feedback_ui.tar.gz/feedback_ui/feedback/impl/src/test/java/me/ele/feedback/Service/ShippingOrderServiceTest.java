package me.ele.feedback.Service;

import me.ele.feedback.lib.sos.TShippingOrder;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Created by majun on 16/3/1.
 */
public class ShippingOrderServiceTest {

    @Test
    public void should_get_shipping_order() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        ShippingOrderService shippingOrderService = (ShippingOrderService) context.getBean("shippingOrderService");

        TShippingOrder shippingOrder = shippingOrderService.getShippingOrder(91423956702853547l);
        System.out.println(shippingOrder);
    }
}