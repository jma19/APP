package me.ele.feedback;

import me.ele.sla.common.util.SignUtil;
import org.junit.Test;

import java.util.TreeMap;

/**
 * Created by majun on 16/3/17.
 */
public class SignUtilTest {
    @Test
    public void testName() throws Exception {
        TreeMap<String, String> params = new TreeMap<>();
        params.put("date", "");
//        params.put("productId", String.valueOf(productId));
//        params.put("page", String.valueOf(page));

    }

    @Test
    public void integer_over_flow() throws Exception {
        int vlaue = Integer.MAX_VALUE + 2;
        System.out.println(vlaue%12);

    }
}
