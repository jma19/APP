package me.ele.feedback.impl;

import me.ele.pylon.spring.util.Bootstrap;

/**
 * Created by yaofeng on 12/28/15.
 */
public class Main {

    public static void main(String args[]) {
        Bootstrap.main(null);
    }

}
