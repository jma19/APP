package me.ele.feedback.api;

import com.google.common.collect.Lists;
import me.ele.feedback.api.bean.TagEntity;
import me.ele.feedback.api.dto.EvaluateTicketDto;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.Timestamp;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

/**
 * Created by majun on 16/2/29.
 */
public class EvaluateServiceTest {

    ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
    @Test
    public void testGetCustomerEvaDriverTags() throws Exception {
        EvaluateService evaluateService = (EvaluateService) context.getBean("evaluateService");
        List<TagEntity> customerEvaDriverTags = evaluateService.getCustomerEvaDriverTags(null, "13");
        assertThat(customerEvaDriverTags.size()>0, is(true));
    }

    @Test
    public void testCreateEvaTicket() throws Exception {
        EvaluateService evaluateService = (EvaluateService) context.getBean("evaluateService");
        EvaluateTicketDto evaluateTicketDto = new EvaluateTicketDto()
                .setStar(1)
                .setTagIds(Lists.newArrayList(1, 2, 3))
                .setTargetName("妖风")
                .setTargetPhone("18168058010")
                .setSourceName("majun")
                .setSourcePhone("13999995678")
                .setRemark("好啰嗦")
                .setOrderId("12774993843712007")
                .setTrackingId(12774993843712007l);

        evaluateService.createEvaTicket(evaluateTicketDto);

    }

    @Test
    public void testName() throws Exception {
        //1970-01-01 08:00:00.0
        System.out.println(new Timestamp(System.currentTimeMillis()));

    }
}