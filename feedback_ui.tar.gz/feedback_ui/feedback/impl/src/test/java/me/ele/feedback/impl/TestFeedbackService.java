package me.ele.feedback.impl;

import com.google.common.collect.Lists;
import me.ele.feedback.api.FeedbackService;
import me.ele.feedback.api.bean.ComplainObject;
import me.ele.feedback.api.dto.FeedbackDto;
import me.ele.feedback.api.dto.FeedbackTicketDto;
import me.ele.feedback.api.dto.UpdateFeedbackDto;
import me.ele.feedback.utils.TimeUtils;
import me.ele.sla.common.util.Base64Util;
import me.ele.sla.common.util.SignUtil;
import org.apache.commons.codec.digest.DigestUtils;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class TestFeedbackService {

    public static String generateSign(TreeMap params, String key) {
        StringBuilder buffer = new StringBuilder();
        Iterator iterator = params.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            String parmasKey = (String) entry.getKey();
            String paramsKey = entry.getValue() == null ? "" : entry.getValue().toString();
            buffer.append(parmasKey).append("=").append(paramsKey).append("&");
        }

        buffer.append(key);
        return DigestUtils.md5Hex(buffer.toString());
    }

    public static boolean checkSign(TreeMap params, String key, String sign) {
        String mySign = generateSign(params, key);
        return mySign.equals(sign);
    }

    @Test
    public void should_update_() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        FeedbackService feedbackService = (FeedbackService) context.getBean("feedbackService");
        UpdateFeedbackDto updateFeedbackDto = new UpdateFeedbackDto();
//        updateFeedbackDto.setId().setStatus();
        feedbackService.updateFeedback(updateFeedbackDto);
    }

    @Test
    public void should_add_feedback() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        FeedbackService feedbackService = (FeedbackService) context.getBean("feedbackService");
        FeedbackDto feedbackDto = new FeedbackDto().setProduct_id(1).setWaybill_num(31414482810400262l).setContent("test").setTypes(Lists.newArrayList(1, 2, 3))
                .setComplaint_phone(Base64Util.encode("13999995678"))
                .setKnight_name("test").setKnight_phone("18168058013");
        feedbackService.addFeedback(feedbackDto);
    }

    @Test
    public void should_create_feedback_and_ticket() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        FeedbackService feedbackService = (FeedbackService) context.getBean("feedbackService");

        FeedbackTicketDto feedbackInsertDto = new FeedbackTicketDto()
                .setSourceId(1)
                .setProductId(1)
                .setComplainType(1)
                .setComplainSource(new ComplainObject().setId(1l).setName("majun").setPhone("172738479391"))
                .setComplainTarget(new ComplainObject().setId(2l).setName("test").setPhone("12473292419"))
                .setComplainReasonIds(Lists.newArrayList())
                .setOrderId("100025374861949164")
                .setTrackingId(11465691851133403l)
                .setComplainAt(System.currentTimeMillis())
                .setSolvedAt(0l)    //solvedAt 填0 有问题
                .setRemark("hello, I think, there is a problem");
        feedbackService.createFeedbackTicket(feedbackInsertDto);
    }


    @Test
    public void should_add_suggestion() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        FeedbackService feedbackService = (FeedbackService) context.getBean("feedbackService");

        FeedbackTicketDto feedbackInsertDto = new FeedbackTicketDto()
                .setSourceId(1)
                .setProductId(1)
                .setComplainType(6)
                .setComplainSource(new ComplainObject().setId(1l).setName("majun").setPhone("172738479391"))
                .setComplainAt(System.currentTimeMillis())
                .setSolvedAt(null)    //solvedAt 填0 有问题
                .setRemark("we should do ....");
        feedbackService.createFeedbackTicket(feedbackInsertDto);
    }

    @Test
    public void testName() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        FeedbackService feedbackService = (FeedbackService) context.getBean("feedbackService");
        TreeMap<String, String> params = new TreeMap<>();
        params.put("date", "2016-03-16");
        params.put("productId", String.valueOf(2));
        System.out.println(SignUtil.generateSign(params, "efd4d064e6eb65f3ce820bbccdee843f"));
        feedbackService.getCountByDateProduct("2016-03-16", 2, "97cd91394db5715bf8115d786ffaac84");
 //sign
    }

    @Test
    public void testMethod() throws Exception {
        Date parse = new SimpleDateFormat("yyyy-MM-dd").parse("1900-01-01 23-23-23");
        System.out.println(TimeUtils.getYMDOfDate("1900-01-01 23-23-23"));
    }
}
