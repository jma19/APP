#!/usr/bin/env bash
mkdir outfile
cp deploy/appspec.yml outfile/
cp deploy/start.sh.etpl outfile/
cp deploy/validate.sh.etpl outfile/
unzip -d outfile/ feedback/impl/target/feedback.zip
